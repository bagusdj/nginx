
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Category List
        <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary button extrasmall pull-right"> <i class="fa fa-puls"></i> Add New</a></h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="<?php echo e(route('category.index')); ?>">
                <input type="hidden" id="pageNumber" value="<?php echo e($page); ?>">
                <table class="table" id="category-table">
                    <thead class=" text-primary">
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Category Name</th>
                            <th style="text-align:center;">Category Logo</th>
                            <th style="text-align:center;">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php if(count($category_data) != 0): ?>
                            <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align:center;">
                                    <?php if($page != ''): ?>
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        <?php echo e(($roNo == 0) ? '' : $roNo); ?><?php echo e(($j==10) ? 0 : $j); ?>

                                    <?php else: ?>
                                        <?php echo e($i++); ?>

                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;"><?php echo e($category->name); ?></td>
                                <td style="text-align:center;">
                                    <a class="popup-youtube" href="<?php echo e(URL::asset('category')); ?><?php echo "/".$category->logo ?>" target="_blank">                                    
                                        <img src="<?php echo e(URL::asset('category')); ?><?php echo "/".$category->logo ?>" style="width:60px; height:60px;">
                                    </a>
                                </td>
                                <td style="text-align:center; width:100px;">                                        
                                    <a href="<?php echo e(route('category.edit',['id'=>$category->id,'page'=>($page == '') ? 0 : $page])); ?>" class="btn btn-sm btn-primary mr-05"> <i class="fa fa-pencil-square-o edit-icon" aria-hidden="true"></i> </a>
                                    <a href="<?php echo e(route('category.delete',['id'=>$category->id,'page'=>($page == '') ? 0 : $page])); ?>" Onclick="return delete_function()" class="btn btn-sm btn-danger mr-05"> <i class="fa fa-trash-o deletable"></i> </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No Record Found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-5">
                        Showing <?php echo e(($category_data->currentpage()-1)*$category_data->perpage()+1); ?> to <?php echo e((($category_data->currentpage()-1)*$category_data->perpage())+$category_data->count()); ?> of  <?php echo e($category_data->total()); ?> entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $category_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_bottom'); ?>
<script>
    $(function() {
        var count = "<?php echo e($category_count); ?>";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
</script>
<script>
    
    function delete_function()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
</script>
<?php $__env->stopSection(); ?>
	







<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>