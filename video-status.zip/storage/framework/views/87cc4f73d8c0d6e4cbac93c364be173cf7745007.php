<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Video List
        <a href="<?php echo e(route('upload_video')); ?>" class="btn btn-primary button extrasmall pull-right"> <i class="fa fa-puls"></i> Add New</a></h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="<?php echo e(route('video_list')); ?>">
                <input type="hidden" id="pageNumber" value="<?php echo e($page); ?>">
                <table class="table" id="video-table">
                    <thead class=" text-primary">
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Video Title</th>
                            <th style="text-align:center;">Category Name</th>
                            <th style="text-align:center;">Language</th>
                            <th style="text-align:center;">Approve</th>
                            <th style="text-align:center;">Trending</th>
                            <th style="text-align:center;">Video Of Day</th>
                            <th style="text-align:center;">Video</th>
                            <th style="text-align:center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php if(count($video_data) != 0): ?>
                            <?php $__currentLoopData = $video_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align:center;">
                                    <?php if($page != ''): ?>
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        <?php echo e(($roNo == 0) ? '' : $roNo); ?><?php echo e(($j==10) ? 0 : $j); ?>

                                    <?php else: ?>
                                        <?php echo e($i++); ?>

                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;"><?php echo e($video->title); ?></td>
                                <?php $category_name= 'Other';
                                    if($video->category_id != '')
                                    {
                                        $category = \App\Category::where('id',$video->category_id)->first();
                                        $category_name = isset($category->name) ? $category->name : '';
                                    } 
                                ?>
                                <td style="text-align:center;"><?php echo e($category_name); ?></td>
                                <td style="text-align:center;"><?php echo e($video->language); ?></td>
                                
                                <?php if($category_name == 'Other'): ?>
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                <?php else: ?>
                                    <td style="text-align:center;"><input type="checkbox" name="status_<?php echo e($video->id); ?>" id="status_<?php echo e($video->id); ?>" data-id="<?php echo e($video->id); ?>" class="css-checkbox" <?php echo e(($video->status == 0) ? '' : "checked"); ?> /><label for="status_<?php echo e($video->id); ?>" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="trending_<?php echo e($video->id); ?>" id="trending_<?php echo e($video->id); ?>" data-id="<?php echo e($video->id); ?>" class="css-checkbox" <?php echo e(($video->trending == 0) ? '' : "checked"); ?> /><label for="trending_<?php echo e($video->id); ?>" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="video_of_day_<?php echo e($video->id); ?>" id="video_of_day_<?php echo e($video->id); ?>" data-id="<?php echo e($video->id); ?>" class="css-checkbox video_of_day" <?php echo e(($video->video_of_day == 0) ? '' : "checked"); ?> /><label for="video_of_day_<?php echo e($video->id); ?>" class="css-label"></label></td>                                
                                <?php endif; ?>
                                <td style="text-align:center;">
                                    <?php if($video->liveurl != ''): ?>
                                    <a class="popup-youtube" href="<?php echo $video->liveurl ?>" target="_NEW">                                    
                                        <img src="<?php echo e(URL::asset('videos/image')); ?><?php echo "/".$video->thumbnail ?>" style="width:60px; height:60px;">
                                    </a>
                                    <?php else: ?>
                                    <a class="popup-youtube" href="<?php echo e(URL::asset('videos')); ?><?php echo "/".$video->path ?>" target="_blank">                                    
                                        <img src="<?php echo e(URL::asset('videos/image')); ?><?php echo "/".$video->thumbnail ?>" style="width:60px; height:60px;">
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center; width:100px;">                                        
                                    <a href="<?php echo e(route('video_notification',['id'=>$video->id])); ?>" class="btn btn-sm btn-info mr-05"> <i class="fa fa-eye" aria-hidden="true"></i> </a>
                                    <a href="<?php echo e(route('video_edit',['id'=>$video->id,'page'=>($page == '') ? 0 : $page])); ?>" class="btn btn-sm btn-primary mr-05"> <i class="fa fa-pencil-square-o edit-icon" aria-hidden="true"></i> </a>
                                    <a href="<?php echo e(route('video_delete',['id'=>$video->id,'page'=>($page == '') ? 0 : $page])); ?>" Onclick="return delete_function()" class="btn btn-sm btn-danger mr-05"> <i class="fa fa-trash-o deletable"></i> </a>    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9">No Record Found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>            
                <div class="row">
                    <div class="col-md-5">
                        Showing <?php echo e(($video_data->currentpage()-1)*$video_data->perpage()+1); ?> to <?php echo e((($video_data->currentpage()-1)*$video_data->perpage())+$video_data->count()); ?> of  <?php echo e($video_data->total()); ?> entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $video_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_bottom'); ?>
<script>
    $(function() {
        var count = "<?php echo e($video_count); ?>";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
    $(document).on('change', '[name^="status_"]',function (event) {
        var id = $(this).data('id');
        var name = "status";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="trending_"]',function (event) {
        var id = $(this).data('id');
        var name = "trending";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="video_of_day_"]',function (event) {
        var id = $(this).data('id');
        var name = "video_of_day";
        $(".video_of_day").parent().removeClass('checked'); 
        $(".video_of_day").prop('checked', false); 
        $(this).parent().addClass('checked'); 
        $(this).prop('checked', true); 
        myFunction(id,name)
    });
    
    function myFunction(id,name){
        $.ajax({
            url: '<?php echo e(route('video_approve')); ?>',
            type: 'post',
            async: false,
            data: {"_token": "<?php echo e(csrf_token()); ?>",'id':id,'name':name},
            dataType: 'JSON',
            success: function(data) {
                if(name == "status"){
                    alert("Approve Status Changes Successfully Save.")
                }else if(name == "trending"){
                    alert("Trending Status Changes Successfully Save.")
                }else{
                    alert("Video Of The Day Changes Successfully Save.")
                }
                // location.reload(true);
            }
        });
    }
    function delete_function()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
</script>
<?php $__env->stopSection(); ?>
	







<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>