<div class="wrapper">
    <?php echo $__env->make('master_all._body_left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-panel">
        <?php echo $__env->make('master_all._app_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('master_all._body_content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('master_all._app_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
