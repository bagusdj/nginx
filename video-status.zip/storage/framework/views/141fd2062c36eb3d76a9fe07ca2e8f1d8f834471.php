<body class="">    
    <?php echo $__env->make('master_all._app_body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->make('master_all._body_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('body_bottom'); ?>
</body>
