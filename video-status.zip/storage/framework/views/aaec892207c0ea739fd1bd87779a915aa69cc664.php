<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">videocam</i>
                    </div>
                    <?php $video = \App\Video::get(); ?>
                    <p class="card-category">Video</p>
                    <h3 class="card-title"><?php echo e(count($video)); ?></h3>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">list</i>
                        <a href="<?php echo e(route('upload_video')); ?>" id="video_list">Add More Videos ...</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">category</i>
                    </div>
                    <?php $category = \App\Category::get(); ?>
                    <p class="card-category">Category</p>
                    <h3 class="card-title"><?php echo e(count($category)); ?></h3>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">list</i> 
                        <a href="<?php echo e(route('category.create')); ?>" id="category_list">Add More Category ...</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-danger card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">translate</i>
                    </div>
                    <?php $language = \App\Language::get(); ?>
                    <p class="card-category">Language</p>
                    <h3 class="card-title"><?php echo e(count($language)); ?></h3>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">list</i> 
                        <a href="<?php echo e(route('language.create')); ?>" id="language_list">Add More Language ...</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">report</i>
                    </div>
                    <?php $report = \App\Report::get(); ?>
                    <p class="card-category">Reports</p>
                    <h3 class="card-title"><?php echo e(count($report)); ?></h3>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">update</i> 
                        <a href="<?php echo e(route('report.index')); ?>" id="report_list">Just Updated ...</a>
                        
                    </div>
                </div>
            </div>
        </div>

        <!--<div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">camera_alt</i>
                    </div>
                    <?php $image = \App\Image::get(); ?>
                    <p class="card-category">Image</p>
                    <h3 class="card-title"><?php echo e(count($image)); ?></h3>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">list</i>
                        <a href="<?php echo e(route('upload_image')); ?>" id="image_list">Add More Images ...</a>
                    </div>
                </div>
            </div>
        </div>-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_bottom'); ?>
<script>
    $('.card-footer a').click(function() {
        sessionStorage.setItem('urlData', $(this).attr('id'));      
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>