
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Report List
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="<?php echo e(route('report.index')); ?>">
                <input type="hidden" id="pageNumber" value="<?php echo e($page); ?>">
                <table class="table" id="report-table">
                    <thead>
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Video Name</th>
                            <th style="text-align:center;">Video Content</th>
                            <th style="text-align:center;">Report Description</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php if(count($report_data) != 0): ?>
                            <?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align:center;">
                                    <?php if($page != ''): ?>
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        <?php echo e(($roNo == 0) ? '' : $roNo); ?><?php echo e(($j==10) ? 0 : $j); ?>

                                    <?php else: ?>
                                        <?php echo e($i++); ?>

                                    <?php endif; ?>
                                </td>
                                <?php $video_data = \App\Video::where('id',$report->report_v_id)->first(); ?>
                                <td style="text-align:center;"><?php echo e(isset($video_data->title) ? $video_data->title : 'Video Deleted'); ?></td>
                                <td style="text-align:center;"><?php echo e($report->report_v_content); ?></td>
                                <td style="text-align:center;"><?php echo e($report->report_description); ?></td>                                        
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No Record Found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-5">
                        Showing <?php echo e(($report_data->currentpage()-1)*$report_data->perpage()+1); ?> to <?php echo e((($report_data->currentpage()-1)*$report_data->perpage())+$report_data->count()); ?> of  <?php echo e($report_data->total()); ?> entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $report_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_bottom'); ?>
<script>
    $(function() {
        var count = "<?php echo e($report_count); ?>";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>