<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Video <?php echo e(($video_data->id) ? "Edit" : "Create"); ?>

            <?php if($page == 0): ?>
                <a href="<?php echo e(route('video_list')); ?>" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            <?php else: ?>
                <a href="<?php echo e(route('video_list',['page'=>($page == '') ? 0 : $page])); ?>" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('video.store')); ?>" files="true" >
                <input type="hidden" name="id" value="<?php echo e($video_data->id); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="page" value="<?php echo e($page); ?>">
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Title <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Video Title" value="<?php echo e($video_data->title); ?>" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Category <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="category_id" required>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key == $video_data->category_id): ?>
                                            <option value="<?php echo e($key); ?>" selected><?php echo e($c); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($c); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Language <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="language" required>
                                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($c == $video_data->language): ?>
                                            <option value="<?php echo e($c); ?>" selected><?php echo e($c); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e(($c == 'Please select') ? '' : $c); ?>"><?php echo e($c); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                <?php if(!isset($video_data->id)): ?>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video File </label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_file">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video URL</label>  
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="" name="upload_url">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video Thumbnail <span class="required">*</span></label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_img">
                                </div> 
                            </div> 
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video URL</label>  
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="" name="upload_url" value="<?php echo e($video_data->liveurl); ?>">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-8 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video Thumbnail </label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_img">
                                </div> 
                            </div> 
                        </div>
                        <div class="col-sm-4 px-0">
                            <div class="form-group ">
                                <img src="<?php echo e(URL::asset('videos/image')); ?><?php echo "/".$video_data->thumbnail ?>" style="width:100px; height:100px;">
                            </div> 
                        </div>
                    </div>
                <?php endif; ?> 
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit"><?php echo e(($video_data->id) ? 'Save' : 'Add'); ?></button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="offset-md-3 col-md-6 padd-custom">
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>