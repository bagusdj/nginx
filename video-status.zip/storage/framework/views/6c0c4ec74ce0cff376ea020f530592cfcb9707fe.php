
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Admob Ids List
        <a href="<?php echo e(route('ids-data.create')); ?>" class="btn btn-primary button extrasmall pull-right"> <i class="fa fa-puls"></i> Add New</a></h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="ids-data-table" style="text-align:center;">
                <?php $i=1 ?>
                <thead>
                    <tr>
                        <th style="text-align:center;">Sr No.</th>
                        <th style="text-align:center;">Ids Name</th>
                        <th style="text-align:center;">Ids Value</th>
                        <th style="text-align:center;">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $i = 1; ?>
                    <?php if(count($ids_data) != 0): ?>
                        <?php $__currentLoopData = $ids_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idsData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:center;"><?php echo e($i++); ?></td>
                            <td style="text-align:center;"><?php echo e(ucwords(str_replace("_"," ",$idsData->id_name))); ?></td>
                            <td style="text-align:center;"><?php echo e($idsData->value); ?></td>
                            <td style="text-align:center; width:100px;">                                        
                                <a href="<?php echo e(route('ids-data.edit',['id'=>$idsData->id])); ?>" class="btn btn-sm btn-primary mr-05"> <i class="fa fa-pencil-square-o edit-icon" aria-hidden="true"></i> </a>
                                <a href="<?php echo e(route('ids-data.delete',['id'=>$idsData->id])); ?>" Onclick="return delete_function()" class="btn btn-sm btn-danger mr-05"> <i class="fa fa-trash-o deletable"></i> </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No Record Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_bottom'); ?>
<script>
    $(document).ready( function () {
        $('#ids-data-table').DataTable();
    });
</script>
<script>
    
    function delete_function()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
</script>
<?php $__env->stopSection(); ?>
	







<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>