

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">URL Notification
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('url_save_notification')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Title <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Your Title" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Message <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <textarea name="msg" class="form-control" id="" cols="30" rows="05" placeholder="Enter Your Message" required></textarea>
                            </div> 
                        </div> 
                    </div>
                </div>   
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Icon <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="url" class="form-control" id="icon" name="icon" placeholder="Enter Your Icon Path" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Image <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="url" class="form-control" id="video_img" name="video_img" placeholder="Enter Your Image Path" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Enter URL <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="url" class="form-control" id="video_url" name="video_url" placeholder="Enter Your URL" value="" required>                            
                            </div> 
                        </div> 
                    </div>
                </div>    
                
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">Send Notification</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>