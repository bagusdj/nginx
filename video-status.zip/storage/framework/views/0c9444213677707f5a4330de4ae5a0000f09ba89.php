<div class="content">
	<div class="container-fluid">
		<!-- Content Section [START] -->
		<div class="">
			<!-- <div class="row main-div"> -->
			<?php echo $__env->yieldContent('content'); ?>
		</div>
		<!-- Content Section [END] -->
	</div>
</div>
