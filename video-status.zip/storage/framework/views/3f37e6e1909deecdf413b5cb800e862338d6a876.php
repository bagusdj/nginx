<!DOCTYPE html>
<html lang="en">
<head>
	<title>Video Status</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(asset('login_design/images/icons/favicon.ico')); ?> "/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/bootstrap/css/bootstrap.min.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/fonts/iconic/css/material-design-iconic-font.min.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/animate/animate.css')); ?> ">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/css-hamburgers/hamburgers.min.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/animsition/css/animsition.min.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/select2/select2.min.css')); ?> ">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/vendor/daterangepicker/daterangepicker.css')); ?> ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/css/util.css')); ?> ">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('login_design/css/main.css')); ?> ">
<!--===============================================================================================-->

</head>
<body>
	<style>
        .help-block{
            color: #3c763d
        }
    </style>
	<div class="limiter">
		<div class="container-login100" style="background:linear-gradient(60deg, #ab47bc, #8e24aa);">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

					<span class="login100-form-title p-b-49">
						Login
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Email is reauired">
						<span class="label-input100">Email</span>
						<input class="input100" id="email" type="email" name="email" placeholder="Enter your email" value="<?php echo e(old('email')); ?>" required autofocus>
						<?php if($errors->has('email')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('email')); ?></strong>
							</span>
						<?php endif; ?>
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" id="password" type="password" name="password" placeholder="Enter your password" required>
						<?php if($errors->has('password')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						<!-- <a href="#">
							Forgot password?
						</a> -->
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" style="background: linear-gradient(60deg, #ab47bc, #8e24aa) !important;">
								Login
							</button>
						</div>
					</div>

					<!-- <div class="txt1 text-center p-t-54 p-b-20">
						<span>
							Or Sign Up Using
						</span>
					</div>

					<div class="flex-c-m">
						<a href="#" class="login100-social-item bg1">
							<i class="fa fa-facebook"></i>
						</a>

						<a href="#" class="login100-social-item bg2">
							<i class="fa fa-twitter"></i>
						</a>

						<a href="#" class="login100-social-item bg3">
							<i class="fa fa-google"></i>
						</a>
					</div> -->

					 <div class="flex-col-c p-t-15">
						<span class="txt1 p-b-17">
							Or Register Using
						</span>

						<a href="<?php echo e(route('register')); ?>" class="txt2">
							Register
						</a>
					</div> 
				</form>
			</div>
		</div>
	</div>	

	<div id="dropDownSelect1"></div>
	<script>sessionStorage.setItem('urlData', '');</script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/animsition/js/animsition.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/bootstrap/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('login_design/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/select2/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/daterangepicker/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('login_design/vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/vendor/countdowntime/countdowntime.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('login_design/js/main.js')); ?>"></script>

</body>
</html>
</html>