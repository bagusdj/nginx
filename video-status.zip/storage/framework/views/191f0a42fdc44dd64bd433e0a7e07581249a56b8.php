

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Category <?php echo e(($category_data->id) ? "Edit" : "Create"); ?>

            <?php if($page == 0): ?>
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            <?php else: ?>
                <a href="<?php echo e(route('category.index',['page'=>($page == '') ? 0 : $page])); ?>" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('category.store')); ?>" files="true" >
                <input type="hidden" name="id" value="<?php echo e($category_data->id); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="page" value="<?php echo e($page); ?>">
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Category Name <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Category Name" value="<?php echo e($category_data->name); ?>" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Category Logo <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="file" class="form-control" id="name" name="logo" placeholder="Category logo" >
                            </div> 
                        </div> 
                    </div>
                </div>       
                
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit"><?php echo e(($category_data->id) ? 'Save' : 'Add'); ?></button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>