<!--   Core JS Files   -->
  <script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap-material-design.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/js/material-dashboard.js?v=2.1.1" type="text/javascript')); ?> "></script>
  <script src="<?php echo e(asset('plugin/validation/js/validator.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugin/snackbar/js/snackbar.js')); ?>"></script>
  <script src="<?php echo e(asset('plugin/pnotify/pnotify.min.js')); ?>"></script>
  <script src="<?php echo e(asset('css/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugin/simplePagination/jquery.simplePagination.js')); ?>"></script>

  <?php echo $__env->make('helper.app_mesage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    $(document).ready(function() {
      $('.sidebar-wrapper .nav .nav-item').removeClass('active')
      $().ready(function() {
        $sidebar = $('.sidebar');

        var menuActive = sessionStorage.getItem('urlData');
        if(menuActive == ''){
          $("#home_list").parent().addClass('active');
        }else{
          $("#"+menuActive).parent().addClass('active');
          sessionStorage.removeItem(menuActive)
        }

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();
        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }
        }        
      });
    });
    $('.sidebar-wrapper .nav .nav-item .nav-link').click(function() {
      sessionStorage.setItem('urlData', $(this).attr('id'));      
    });
  </script>
  <script>
    $(document).ready(function() {
      md.initDashboardPageCharts();
    });
  </script>
