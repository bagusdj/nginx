 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?php echo e(isset($title) ? $title : 'Video Status'); ?></title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- Application CSS-->

        <link href="<?php echo e(asset('assets/css/material-dashboard.css?v=2.1.1')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('plugin/snackbar/css/snackbar.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('plugin/simplePagination/simplePagination.css')); ?>" rel="stylesheet" type="text/css" />
        
        <!-- Application CSS END -->
    </head>
    <?php echo $__env->make('master_all._body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>
