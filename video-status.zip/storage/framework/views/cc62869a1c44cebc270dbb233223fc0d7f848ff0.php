<script type="text/javascript">

    <?php if(Session::has('success')): ?>
        Snackbar.show({text: '<?php echo e(Session::get('success')); ?>', pos: 'bottom-center'});
    <?php endif; ?>

    <?php if(isset($errors) && $errors->any()): ?>
        Snackbar.show({text: '<?php echo e($errors->first()); ?>', pos: 'bottom-center'});
    <?php endif; ?>

</script>