<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Auth::routes();

Route::group(['middleware' => ['auth']], function () {
    Route::get('/', 'HomeController@index');
    Route::get('/home', 'HomeController@index')->name('home');

	//Video Module
    Route::any('upload-video','WebVideoController@Videocreate')->name('upload_video');
    Route::any('video-save','WebVideoController@Videostore')->name('video.store');
    Route::any('video-list','WebVideoController@Videoindex')->name('video_list');
    Route::get('videoData', ['as' => 'video.getData', 'uses' => 'WebVideoController@videoGetData']);
    Route::any('video-edit','WebVideoController@Videocreate')->name('video_edit');
    Route::any('video-approve','WebVideoController@Videoapprove')->name('video_approve');
    Route::any('video-delete','WebVideoController@VideoDelete')->name('video_delete');

    Route::any('notification','NotificationController@Notification')->name('all_notification');
    Route::any('notification/save','NotificationController@NotificationSave')->name('send_notification');

    Route::any('notification/video','NotificationController@VideoNotification')->name('video_notification');
    Route::any('notification/video/save','NotificationController@VideoNotificationSave')->name('video_save_notification');

    Route::any('notification/url','NotificationController@URLNotification')->name('url_notification');
    Route::any('notification/url/save','NotificationController@URLNotificationSave')->name('url_save_notification');

    //Image Module
    Route::any('upload-image','WebImageController@Imagecreate')->name('upload_image');
    Route::any('image-save','WebImageController@Imagestore')->name('image.store');
    Route::any('image-list','WebImageController@Imageindex')->name('image_list');
    Route::get('imageData', ['as' => 'image.getData', 'uses' => 'WebImageController@imageGetData']);
    Route::any('image-edit','WebImageController@Imagecreate')->name('image_edit');
    Route::any('image-approve','WebImageController@Imageapprove')->name('image_approve');
    Route::any('image-delete','WebImageController@ImageDelete')->name('image_delete');

    Route::any('notification','NotificationController@Notification')->name('all_notification');
    Route::any('notification/save','NotificationController@NotificationSave')->name('send_notification');

    Route::any('notification/image','NotificationController@ImageNotification')->name('image_notification');
    Route::any('notification/image/save','NotificationController@ImageNotificationSave')->name('image_save_notification');

    // Route::any('notification/url','NotificationController@URLNotification')->name('url_notification');
    // Route::any('notification/url/save','NotificationController@URLNotificationSave')->name('url_save_notification');

    //category Data 
	// Route::resource('/category', 'CategoryController'); 
    Route::any('/category/index','CategoryController@index')->name('category.index');
    Route::any('/category/create/','CategoryController@create')->name('category.create');
    Route::any('/category/edit/{id}','CategoryController@create')->name('category.edit');
	Route::any('/category/store','CategoryController@store')->name('category.store');
	Route::any('/category/delete/{id}','CategoryController@destroy')->name('category.delete');
    
    //language Data 
	// Route::resource('/language', 'LanguageController'); 
    Route::any('/language/index','LanguageController@index')->name('language.index');
    Route::any('/language/create/','LanguageController@create')->name('language.create');
    Route::any('/language/edit/{id}','LanguageController@create')->name('language.edit');
	Route::any('/language/store','LanguageController@store')->name('language.store');
    Route::any('/language/delete/{id}','LanguageController@destroy')->name('language.delete');
    
    //Report Data
    Route::any('/report/index','StaticController@reportindex')->name('report.index');

    //change pwd Data
    Route::any('/change-password/','StaticController@changePWD')->name('change_pwd');
    Route::any('/change-password/store','StaticController@changePWDStore')->name('changePWD.store');    

    Route::any('/ids-data/index','IdsDataController@index')->name('ids-data.index');
    Route::any('/ids-data/create/','IdsDataController@create')->name('ids-data.create');
    Route::any('/ids-data/edit/{id}','IdsDataController@create')->name('ids-data.edit');
    Route::any('/ids-data/store','IdsDataController@store')->name('ids-data.store');
    Route::any('/ids-data/delete/{id}','IdsDataController@destroy')->name('ids-data.delete');

    Route::any('/redeem/index','StaticController@redeemindex')->name('redeem.index');
    Route::any('/redeem/complete/','StaticController@redeemcomplete')->name('redeem.complete');
});




