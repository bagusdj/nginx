<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::any('/video-list','VideoController@VideoList');

Route::any('/category-lang','StaticController@CategoryLanguage');

Route::any('/search-list','VideoController@SearchList');
Route::any('/search-video','VideoController@SearchVideoList');

Route::any('/trending-video','VideoController@TrendingVideo');

Route::any('/video-upload','VideoController@VideoUpload');

Route::any('/popular-video','VideoController@PopularVideoList');

Route::any('/related-video','VideoController@RelatedVideoList');

Route::any('/reports','VideoController@Reports');

Route::any('/save-viewlike','VideoController@ViewLikeSave');

Route::any('/register-notificaton','VideoController@RegisterNotificaton');

Route::any('/add-video-point','VideoController@AppVideoPoint');

Route::any('/ids-list','IdsDataController@index');

Route::any('/save-downloadcount','VideoController@DownloadCount');


/*--------Image-----*/

Route::any('/image-list','ImageController@ImageList');

//Route::any('/category-lang','StaticController@CategoryLanguage');

Route::any('/searchimg-list','ImageController@SearchimgList');
Route::any('/search-image','ImageController@SearchImageList');

Route::any('/trending-image','ImageController@TrendingImage');

Route::any('/image-upload','ImageController@ImageUpload');

Route::any('/popular-image','ImageController@PopularImageList');

Route::any('/related-image','ImageController@RelatedImageList');

Route::any('/image-reports','ImageController@imageReports');

Route::any('/save-viewlikeimage','ImageController@ImageViewLikeSave');

Route::any('/register-imagenotificaton','ImageController@RegisterImageNotificaton');

//Route::any('/ids-list','IdsDataController@index');
Route::any('/add-image-point','ImageController@AppImagePoint');

Route::any('/login','Auth\LoginController@loginApiSide');

Route::any('/register','Auth\RegisterController@registerApiSide');

Route::any('/save-downloadcountimage','ImageController@DownloadCountImage');

/*================================================================*/

Route::any('/phone-no','StaticController@PhoneNo');

Route::any('/redeem_request','StaticController@Redeem');