@extends('layouts.appmaster')
@section('content')
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Report List
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="{{route('report.index')}}">
                <input type="hidden" id="pageNumber" value="{{$page}}">
                <table class="table" id="report-table">
                    <thead>
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Video Name</th>
                            <th style="text-align:center;">Video Content</th>
                            <th style="text-align:center;">Report Description</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        @if(count($report_data) != 0)
                            @foreach($report_data as $report)
                            <tr>
                                <td style="text-align:center;">
                                    @if($page != '')
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        {{($roNo == 0) ? '' : $roNo}}{{($j==10) ? 0 : $j}}
                                    @else
                                        {{$i++}}
                                    @endif
                                </td>
                                <?php $video_data = \App\Video::where('id',$report->report_v_id)->first(); ?>
                                <td style="text-align:center;">{{ isset($video_data->title) ? $video_data->title : 'Video Deleted'}}</td>
                                <td style="text-align:center;">{{ $report->report_v_content }}</td>
                                <td style="text-align:center;">{{ $report->report_description }}</td>                                        
                            </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="4">No Record Found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-5">
                        Showing {{($report_data->currentpage()-1)*$report_data->perpage()+1}} to {{(($report_data->currentpage()-1)*$report_data->perpage())+$report_data->count()}} of  {{$report_data->total()}} entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $report_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('body_bottom')
<script>
    $(function() {
        var count = "{{$report_count}}";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
</script>
@endsection
