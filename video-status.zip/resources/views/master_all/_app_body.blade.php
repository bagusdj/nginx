<div class="wrapper">
    @include('master_all._body_left_sidebar')
    <div class="main-panel">
        @include('master_all._app_header')
        @include('master_all._body_content')
        @include('master_all._app_footer')
    </div>
</div>
