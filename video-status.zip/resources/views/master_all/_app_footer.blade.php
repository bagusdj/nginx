<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script> All Rights Reserved, Powered by Hidea Infosys.
        </div>
    </div>
</footer>