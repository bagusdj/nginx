<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
    <div class="logo">
        <a class="simple-text logo-normal">
            Video Status
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" id="home_list" href="{{route('home')}}">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="video_list" href="{{route('video_list')}}">
                    <i class="material-icons">video_call</i>
                    <p>Video</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="category_list" href="{{route('category.index')}}">
                    <i class="material-icons">category</i>
                    <p>Category</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="language_list" href="{{route('language.index')}}">
                    <i class="material-icons">language</i>
                    <p>Language</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="report_list" href="{{route('report.index')}}">
                    <i class="material-icons">report</i>
                    <p>Reports</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="video_notification_list" href="{{route('video_notification')}}">
                    <i class="fa fa-file-video-o" aria-hidden="true"></i>
                    <p>Video Notification</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="url_notification_list" href="{{route('url_notification')}}">
                    <i class="material-icons">music_video</i>
                    <p>URL Notification</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="all_notification_list" href="{{route('all_notification')}}">
                    <i class="material-icons">notifications</i>
                    <p>Simple Notification</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="admob_ids" href="{{route('ids-data.index')}}">
                    <i class="material-icons">control_camera</i>
                    <p>Admob Ids</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" id="change_pwd_list" href="{{route('change_pwd')}}">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <p>Change Password</p>
                </a>
            </li>
        </ul>
    </div>
</div>