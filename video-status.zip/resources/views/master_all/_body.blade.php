<body class="">    
    @include('master_all._app_body')    
    @include('master_all._body_js')
    @yield('body_bottom')
</body>
