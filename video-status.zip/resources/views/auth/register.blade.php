<!DOCTYPE html>
<html lang="en">
<head>
	<title>Video Status</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="{{ asset('login_design/images/icons/favicon.ico')}} "/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/bootstrap/css/bootstrap.min.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/fonts/font-awesome-4.7.0/css/font-awesome.min.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/fonts/iconic/css/material-design-iconic-font.min.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/animate/animate.css')}} ">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/css-hamburgers/hamburgers.min.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/animsition/css/animsition.min.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/select2/select2.min.css')}} ">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/vendor/daterangepicker/daterangepicker.css')}} ">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/css/util.css')}} ">
	<link rel="stylesheet" type="text/css" href="{{ asset('login_design/css/main.css')}} ">
<!--===============================================================================================-->

</head>
<body>
	<style>
        .help-block{
            color: #3c763d
        }
    </style>
	<div class="limiter">
		<div class="container-login100" style="background:linear-gradient(60deg, #ab47bc, #8e24aa);">
		<!-- <div class="container-login100" style="background-image: url('login_design/images/bg-01.jpg');"> -->
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                <form class="login100-form validate-form" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}
					<span class="login100-form-title p-b-49">
                        Register
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Name is reauired">
						<span class="label-input100">Name</span>
						<input class="input100" id="name" type="text" name="name" placeholder="Enter your Name" value="{{ old('name') }}" required autofocus>
                        @if ($errors->has('name'))
                            <span class="help-block">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
						<span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>
                    
                    <div class="wrap-input100 validate-input m-b-23" data-validate = "E-Mail Address is reauired">
						<span class="label-input100">E-Mail Address</span>
						<input class="input100" id="email" type="text" name="email" placeholder="Enter your email" value="{{ old('email') }}" required>
                        @if ($errors->has('email'))
                            <span class="help-block">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                        @endif
						<span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>
                    
                    <div class="wrap-input100 validate-input m-b-23" data-validate="Password is required">
                        <span class="label-input100">Password</span>
						<input class="input100" id="password" type="password" name="password" placeholder="Enter your password" required>                        
                        @if ($errors->has('password'))
                            <span class="help-block">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                        @endif
						<span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <span class="label-input100">Confirm Password</span>
						<input class="input100" id="password-confirm" type="password" name="password_confirmation" placeholder="Enter confirmation password" required>
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>

					<div class="text-right p-t-8 p-b-31">
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" style="background: linear-gradient(60deg, #ab47bc, #8e24aa) !important;">
								Register
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>	

	<div id="dropDownSelect1"></div>
	<script>sessionStorage.setItem('urlData', '');</script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/jquery/jquery-3.2.1.min.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/animsition/js/animsition.min.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/bootstrap/js/popper.js') }}"></script>
	<script src="{{ asset('login_design/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/select2/select2.min.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/daterangepicker/moment.min.js') }}"></script>
	<script src="{{ asset('login_design/vendor/daterangepicker/daterangepicker.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/vendor/countdowntime/countdowntime.js') }}"></script>
<!--===============================================================================================-->
	<script src="{{ asset('login_design/js/main.js') }}"></script>

</body>
</html>
</html>