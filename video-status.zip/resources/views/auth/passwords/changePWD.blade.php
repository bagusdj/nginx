@extends('layouts.appmaster')

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Change Password
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="{{route('changePWD.store')}}" files="true" >
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">New Password <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter New Password" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Confirm Password <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="password" class="form-control" id="confirm_pwd" name="confirm_pwd" placeholder="Enter Confirm Password" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>       
                
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection