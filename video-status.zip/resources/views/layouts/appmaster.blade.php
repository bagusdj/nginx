 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>{{ $title or 'Video Status' }}</title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- Application CSS-->

        <link href="{{ asset('assets/css/material-dashboard.css?v=2.1.1') }}" rel="stylesheet" />
        <link href="{{ asset('plugin/snackbar/css/snackbar.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('css/datatables/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet" type="text/css"/>
        <link href="{{ asset('plugin/simplePagination/simplePagination.css') }}" rel="stylesheet" type="text/css" />
        
        <!-- Application CSS END -->
    </head>
    @include('master_all._body')
</html>
