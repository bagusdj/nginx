@extends('layouts.appmaster')

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Admob Ids {{($ids_data->id) ? "Edit" : "Create"}}
            <a href="{{route('ids-data.index')}}" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="{{route('ids-data.store')}}" files="true" >
                <input type="hidden" name="id" value="{{$ids_data->id}}">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Admob Ids Name <span class="required">*</span></label>  
                            <div class="col-md-12">                            
                                <select name="id_name" class="form-control" required {{isset($ids_data->id) ? '' : 'disabled'}}disabled>
                                    <option value="">Please Select</option>
                                    <option value="banner_id" {{ ($ids_data->id_name == "banner_id") ? "selected" : ''}}>Banner Id</option>
                                    <option value="interstitial_id" {{ ($ids_data->id_name == "interstitial_id") ? "selected" : ''}}>Interstitial Id</option>
                                    <option value="video_id" {{ ($ids_data->id_name == "video_id") ? "selected" : ''}}>Video Id</option>
                                    <option value="image_id" {{ ($ids_data->id_name == "image_id") ? "selected" : ''}}>Image Id</option>
                                </select> 
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Admob Ids Value </label>  
                            <div class="col-md-12">
                                <input type="test" class="form-control" id="value" name="value" placeholder="Enter Admob Ids Value" value="{{$ids_data->value}}">
                            </div> 
                        </div> 
                    </div>
                </div>       
                
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">{{($ids_data->id) ? 'Save' : 'Add'}}</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection