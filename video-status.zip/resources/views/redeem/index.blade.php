@extends('layouts.appmaster')
@section('content')
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Redeem Request List
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="{{route('redeem.index')}}">
                <input type="hidden" id="pageNumber" value="{{$page}}">
                <table class="table" id="language-table">
                    <thead>
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">User Name</th>
                            <th style="text-align:center;">Balance</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        @if(count($redeem_data) != 0)
                            @foreach($redeem_data as $redeem)
                            <tr>
                                <td style="text-align:center;">
                                    @if($page != '')
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        {{($roNo == 0) ? '' : $roNo}}{{($j==10) ? 0 : $j}}
                                    @else
                                        {{$i++}}
                                    @endif
                                </td>
                                <td style="text-align:center;">{{$redeem->name}}</td>
                                <td style="text-align:center;">{{$redeem->balance}}</td>
                                <td style="text-align:center; width:100px;">                                        
                                    
                                    <a class="btn btn-danger" Onclick="return delete_function()" href="{{route('redeem.complete',['redeem_id'=>$redeem->redeem_id,'page'=>($page == '') ? 0 : $page])}}">Complete</a>

                                </td>
                            </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="3">No Record Found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-5">
                        Showing {{($redeem_data->currentpage()-1)*$redeem_data->perpage()+1}} to {{(($redeem_data->currentpage()-1)*$redeem_data->perpage())+$redeem_data->count()}} of  {{$redeem_data->total()}} entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $redeem_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
	
@section('body_bottom')
<script>
    $(function() {
        var count = "{{$redeem_count}}";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
</script>
<script>    
    function delete_function()
    {
        var x = confirm("Are you sure you want to complete this redeem request?");
        if (x)
            return true;
        else
            return false;
    }
</script>
@endsection
