@extends('layouts.appmaster')

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Video {{($video_data->id) ? "Edit" : "Create"}}
            @if($page == 0)
                <a href="{{route('video_list')}}" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            @else
                <a href="{{route('video_list',['page'=>($page == '') ? 0 : $page])}}" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            @endif
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="{{route('video.store')}}" files="true" >
                <input type="hidden" name="id" value="{{$video_data->id}}">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="page" value="{{ $page }}">
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Title <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Video Title" value="{{$video_data->title}}" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Category <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="category_id" required>
                                    @foreach($category as $key => $c)
                                        @if($key == $video_data->category_id)
                                            <option value="{{ $key }}" selected>{{ $c }}</option>
                                        @else
                                            <option value="{{ $key }}">{{ $c }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Video Language <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="language" required>
                                    @foreach($language as $c)
                                        @if($c == $video_data->language)
                                            <option value="{{ $c }}" selected>{{ $c }}</option>
                                        @else
                                            <option value="{{ ($c == 'Please select') ? '' : $c }}">{{ $c }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                @if(!isset($video_data->id))
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video File </label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_file">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video URL</label>  
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="" name="upload_url">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video Thumbnail <span class="required">*</span></label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_img">
                                </div> 
                            </div> 
                        </div>
                    </div>
                @else
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video URL</label>  
                                <div class="col-md-12">
                                    <input type="text" class="form-control" id="" name="upload_url" value="{{$video_data->liveurl}}">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="row text-title pall-0">
                        <div class="col-sm-8 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Video Thumbnail </label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="video_img">
                                </div> 
                            </div> 
                        </div>
                        <div class="col-sm-4 px-0">
                            <div class="form-group ">
                                <img src="{{URL::asset('videos/image')}}<?php echo "/".$video_data->thumbnail ?>" style="width:100px; height:100px;">
                            </div> 
                        </div>
                    </div>
                @endif 
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">{{($video_data->id) ? 'Save' : 'Add'}}</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="offset-md-3 col-md-6 padd-custom">
    

@endsection