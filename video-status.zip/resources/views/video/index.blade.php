@extends('layouts.appmaster')
@section('content')
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Video List
        <a href="{{ route('upload_video') }}" class="btn btn-primary button extrasmall pull-right"> <i class="fa fa-puls"></i> Add New</a></h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="{{route('video_list')}}">
                <input type="hidden" id="pageNumber" value="{{$page}}">
                <table class="table" id="video-table">
                    <thead class=" text-primary">
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Video Title</th>
                            <th style="text-align:center;">Category Name</th>
                            <th style="text-align:center;">Language</th>
                            <th style="text-align:center;">Approve</th>
                            <th style="text-align:center;">Trending</th>
                            <th style="text-align:center;">Video Of Day</th>
                            <th style="text-align:center;">Video</th>
                            <th style="text-align:center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        @if(count($video_data) != 0)
                            @foreach($video_data as $video)
                            <tr>
                                <td style="text-align:center;">
                                    @if($page != '')
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        {{($roNo == 0) ? '' : $roNo}}{{($j==10) ? 0 : $j}}
                                    @else
                                        {{$i++}}
                                    @endif
                                </td>
                                <td style="text-align:center;">{{$video->title}}</td>
                                <?php $category_name= 'Other';
                                    if($video->category_id != '')
                                    {
                                        $category = \App\Category::where('id',$video->category_id)->first();
                                        $category_name = isset($category->name) ? $category->name : '';
                                    } 
                                ?>
                                <td style="text-align:center;">{{$category_name}}</td>
                                <td style="text-align:center;">{{$video->language}}</td>
                                
                                @if($category_name == 'Other')
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                @else
                                    <td style="text-align:center;"><input type="checkbox" name="status_{{$video->id}}" id="status_{{$video->id}}" data-id="{{$video->id}}" class="css-checkbox" {{($video->status == 0) ? '' : "checked" }} /><label for="status_{{$video->id}}" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="trending_{{$video->id}}" id="trending_{{$video->id}}" data-id="{{$video->id}}" class="css-checkbox" {{($video->trending == 0) ? '' : "checked" }} /><label for="trending_{{$video->id}}" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="video_of_day_{{$video->id}}" id="video_of_day_{{$video->id}}" data-id="{{$video->id}}" class="css-checkbox video_of_day" {{($video->video_of_day == 0) ? '' : "checked" }} /><label for="video_of_day_{{$video->id}}" class="css-label"></label></td>                                
                                @endif
                                <td style="text-align:center;">
                                    @if($video->liveurl != '')
                                    <a class="popup-youtube" href="<?php echo $video->liveurl ?>" target="_NEW">                                    
                                        <img src="{{URL::asset('videos/image')}}<?php echo "/".$video->thumbnail ?>" style="width:60px; height:60px;">
                                    </a>
                                    @else
                                    <a class="popup-youtube" href="{{URL::asset('videos')}}<?php echo "/".$video->path ?>" target="_blank">                                    
                                        <img src="{{URL::asset('videos/image')}}<?php echo "/".$video->thumbnail ?>" style="width:60px; height:60px;">
                                    </a>
                                    @endif
                                </td>
                                <td style="text-align:center; width:100px;">                                        
                                    <a href="{{route('video_notification',['id'=>$video->id])}}" class="btn btn-sm btn-info mr-05"> <i class="fa fa-eye" aria-hidden="true"></i> </a>
                                    <a href="{{route('video_edit',['id'=>$video->id,'page'=>($page == '') ? 0 : $page])}}" class="btn btn-sm btn-primary mr-05"> <i class="fa fa-pencil-square-o edit-icon" aria-hidden="true"></i> </a>
                                    <a href="{{route('video_delete',['id'=>$video->id,'page'=>($page == '') ? 0 : $page])}}" Onclick="return delete_function()" class="btn btn-sm btn-danger mr-05"> <i class="fa fa-trash-o deletable"></i> </a>    
                                </td>
                            </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="9">No Record Found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>            
                <div class="row">
                    <div class="col-md-5">
                        Showing {{($video_data->currentpage()-1)*$video_data->perpage()+1}} to {{(($video_data->currentpage()-1)*$video_data->perpage())+$video_data->count()}} of  {{$video_data->total()}} entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $video_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('body_bottom')
<script>
    $(function() {
        var count = "{{$video_count}}";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
    $(document).on('change', '[name^="status_"]',function (event) {
        var id = $(this).data('id');
        var name = "status";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="trending_"]',function (event) {
        var id = $(this).data('id');
        var name = "trending";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="video_of_day_"]',function (event) {
        var id = $(this).data('id');
        var name = "video_of_day";
        $(".video_of_day").parent().removeClass('checked'); 
        $(".video_of_day").prop('checked', false); 
        $(this).parent().addClass('checked'); 
        $(this).prop('checked', true); 
        myFunction(id,name)
    });
    
    function myFunction(id,name){
        $.ajax({
            url: '{{ route('video_approve') }}',
            type: 'post',
            async: false,
            data: {"_token": "{{ csrf_token() }}",'id':id,'name':name},
            dataType: 'JSON',
            success: function(data) {
                if(name == "status"){
                    alert("Approve Status Changes Successfully Save.")
                }else if(name == "trending"){
                    alert("Trending Status Changes Successfully Save.")
                }else{
                    alert("Video Of The Day Changes Successfully Save.")
                }
                // location.reload(true);
            }
        });
    }
    function delete_function()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
</script>
@endsection
	






