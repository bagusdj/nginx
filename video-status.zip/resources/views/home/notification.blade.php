@extends('layouts.appmaster')

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Simple Notification
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="{{route('send_notification')}}">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Title <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Your Title" value="" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0 pt-10">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Message <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <textarea name="msg" class="form-control" id="" cols="30" rows="10" placeholder="Enter Your Message" required></textarea>
                            </div> 
                        </div> 
                    </div>
                </div>       
                
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">Send</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection