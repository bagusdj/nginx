@extends('layouts.appmaster')
@section('content')
<div class="col-md-12">
    <div class="card">
    <div class="card-header card-header-primary">
        <h4 class="card-title ">Image List
        <a href="{{ route('upload_image') }}" class="btn btn-primary button extrasmall pull-right"> <i class="fa fa-puls"></i> Add New</a></h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <input type="hidden" id="getURL" value="{{route('image_list')}}">
                <input type="hidden" id="pageNumber" value="{{$page}}">
                <table class="table" id="image-table">
                    <thead class=" text-primary">
                        <tr>
                            <th style="text-align:center;">Sr No.</th>
                            <th style="text-align:center;">Image Title</th>
                            <th style="text-align:center;">Category Name</th>
                            <th style="text-align:center;">Language</th>
                            <th style="text-align:center;">Approve</th>
                            <th style="text-align:center;">Trending</th>
                            <th style="text-align:center;">Image Of Day</th>
                            <th style="text-align:center;">Image</th>
                            <th style="text-align:center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        @if(count($image_data) != 0)
                            @foreach($image_data as $image)
                            <tr>
                                <td style="text-align:center;">
                                    @if($page != '')
                                        <?php $roNo = ($i == 10) ? ($page) : ($page-1); $j = $i++?>
                                        {{($roNo == 0) ? '' : $roNo}}{{($j==10) ? 0 : $j}}
                                    @else
                                        {{$i++}}
                                    @endif
                                </td>
                                <td style="text-align:center;">{{$image->title}}</td>
                                <?php $category_name= 'Other';
                                    if($image->category_id != '')
                                    {
                                        $category = \App\Category::where('id',$image->category_id)->first();
                                        $category_name = isset($category->name) ? $category->name : '';
                                    } 
                                ?>
                                <td style="text-align:center;">{{$category_name}}</td>
                                <td style="text-align:center;">{{$image->language}}</td>
                                
                                @if($category_name == 'Other')
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                    <td style="text-align:center;">Add Category</td>
                                @else
                                    <td style="text-align:center;"><input type="checkbox" name="status_{{$image->id}}" id="status_{{$image->id}}" data-id="{{$image->id}}" class="css-checkbox" {{($image->status == 0) ? '' : "checked" }} /><label for="status_{{$image->id}}" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="trending_{{$image->id}}" id="trending_{{$image->id}}" data-id="{{$image->id}}" class="css-checkbox" {{($image->trending == 0) ? '' : "checked" }} /><label for="trending_{{$image->id}}" class="css-label"></label></td>
                                    <td style="text-align:center;"><input type="checkbox" name="image_of_day_{{$image->id}}" id="image_of_day_{{$image->id}}" data-id="{{$image->id}}" class="css-checkbox image_of_day" {{($image->image_of_day == 0) ? '' : "checked" }} /><label for="image_of_day_{{$image->id}}" class="css-label"></label></td>                                
                                @endif
                                <td style="text-align:center;">
                                    <a class="popup-youtube" href="{{URL::asset('image')}}<?php echo "/".$image->image ?>" target="_blank">                                    
                                        <img src="{{URL::asset('image')}}<?php echo "/".$image->image ?>" style="width:60px; height:60px;">
                                    </a>
                                </td>
                                <td style="text-align:center; width:100px;">                                        
                                    <a href="{{route('image_notification',['id'=>$image->id])}}" class="btn btn-sm btn-info mr-05"> <i class="fa fa-eye" aria-hidden="true"></i> </a>
                                    <a href="{{route('image_edit',['id'=>$image->id,'page'=>($page == '') ? 0 : $page])}}" class="btn btn-sm btn-primary mr-05"> <i class="fa fa-pencil-square-o edit-icon" aria-hidden="true"></i> </a>
                                    <a href="{{route('image_delete',['id'=>$image->id,'page'=>($page == '') ? 0 : $page])}}" Onclick="return delete_function()" class="btn btn-sm btn-danger mr-05"> <i class="fa fa-trash-o deletable"></i> </a>    
                                </td>
                            </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="9">No Record Found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>            
                <div class="row">
                    <div class="col-md-5">
                        Showing {{($image_data->currentpage()-1)*$image_data->perpage()+1}} to {{(($image_data->currentpage()-1)*$image_data->perpage())+$image_data->count()}} of  {{$image_data->total()}} entries
                    </div>
                    <div class="col-md-5 pull-right">
                        <?php echo $image_data->links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('body_bottom')
<script>
    $(function() {
        var count = "{{$image_count}}";
        var perPage = 10;
        $('.pagination').parent().pagination({
            items: count,
            itemsOnPage: perPage,
            cssStyle: 'light-theme'
        });
    });
    $(document).on('change', '[name^="status_"]',function (event) {
        var id = $(this).data('id');
        var name = "status";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="trending_"]',function (event) {
        var id = $(this).data('id');
        var name = "trending";
        myFunction(id,name)
    });
    $(document).on('change', '[name^="image_of_day_"]',function (event) {
        var id = $(this).data('id');
        var name = "image_of_day";
        $(".image_of_day").parent().removeClass('checked'); 
        $(".image_of_day").prop('checked', false); 
        $(this).parent().addClass('checked'); 
        $(this).prop('checked', true); 
        myFunction(id,name)
    });
    
    function myFunction(id,name){
        $.ajax({
            url: '{{ route('image_approve') }}',
            type: 'post',
            async: false,
            data: {"_token": "{{ csrf_token() }}",'id':id,'name':name},
            dataType: 'JSON',
            success: function(data) {
                if(name == "status"){
                    alert("Approve Status Changes Successfully Save.")
                }else if(name == "trending"){
                    alert("Trending Status Changes Successfully Save.")
                }else{
                    alert("Image Of The Day Changes Successfully Save.")
                }
                // location.reload(true);
            }
        });
    }
    function delete_function()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
</script>
@endsection
	






