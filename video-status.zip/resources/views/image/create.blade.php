@extends('layouts.appmaster')

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Image {{($image_data->id) ? "Edit" : "Create"}}
            @if($page == 0)
                <a href="{{route('image_list')}}" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            @else
                <a href="{{route('image_list',['page'=>($page == '') ? 0 : $page])}}" class="btn btn-primary button extrasmall pull-right"> Back</a></h4>
            @endif
        </div>
        <div class="card-body">
            <form enctype="multipart/form-data" method="post" action="{{route('image.store')}}" files="true" >
                <input type="hidden" name="id" value="{{$image_data->id}}">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="page" value="{{ $page }}">
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Image Title <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Image Title" value="{{$image_data->title}}" required>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Image Category <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="category_id" required>
                                    @foreach($category as $key => $c)
                                        @if($key == $image_data->category_id)
                                            <option value="{{ $key }}" selected>{{ $c }}</option>
                                        @else
                                            <option value="{{ $key }}">{{ $c }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group ">
                            <label class="col-md-12 control-label">Image Language <span class="required">*</span></label>  
                            <div class="col-md-12">
                                <select class="form-control" name="language" required>
                                    @foreach($language as $c)
                                        @if($c == $image_data->language)
                                            <option value="{{ $c }}" selected>{{ $c }}</option>
                                        @else
                                            <option value="{{ ($c == 'Please select') ? '' : $c }}">{{ $c }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div> 
                        </div> 
                    </div>
                </div>
                @if(!isset($image_data->id))
                    <!-- <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Gif File <span class="required">*</span></label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="gif_file">
                                </div> 
                            </div> 
                        </div>
                    </div> -->
                    <div class="row text-title pall-0">
                        <div class="col-sm-12 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Image Thumbnail <span class="required">*</span></label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="image_file">
                                </div> 
                            </div> 
                        </div>
                    </div>
                @else
                    <div class="row text-title pall-0">
                        <div class="col-sm-8 px-0">
                            <div class="form-group ">
                                <label class="col-md-12 control-label">Image Thumbnail </label>  
                                <div class="col-md-12">
                                    <input type="file" class="form-control" id="" name="image_file">
                                </div> 
                            </div> 
                        </div>
                        <div class="col-sm-4 px-0">
                            <div class="form-group ">
                                <img src="{{URL::asset('image')}}<?php echo "/".$image_data->image ?>" style="width:100px; height:100px;">
                            </div> 
                        </div>
                    </div>
                @endif 
                <div class="row text-title pall-0">
                    <div class="col-sm-12 px-0">
                        <div class="form-group">
                            <div class="col-md-12 text-center">  
                                <button class="btn btn-primary" type="submit">{{($image_data->id) ? 'Save' : 'Add'}}</button>
                            </div> 
                        </div> 
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="offset-md-3 col-md-6 padd-custom">
    

@endsection