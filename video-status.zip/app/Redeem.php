<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Redeem extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'redeem_management';
    protected $fillable = ['user_id','email','phone','complete_flag','balance','date'];

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}
