<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'languages';
    protected $fillable = ['value'];
}
