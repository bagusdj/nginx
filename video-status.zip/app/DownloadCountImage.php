<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DownloadCountImage extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'downloadcount_image';
    protected $fillable = ['image_id','uid'];
}
