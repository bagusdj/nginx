<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'images';
    protected $fillable = ['image','size','view','category_id','title','language_id','language','image_of_day','user_id','username','email'];

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}
