<?php
/* file exits check*/
function fileExitsCheck($defaultimg, $path, $filename)
{
    $image= $defaultimg;
    $imgurl= public_path($path.'/'.$filename);
    if ($filename != null && file_exists($imgurl)) {
        $isimgurl=URL::asset($path.'/'.$filename);
        $image=$isimgurl;
    }
    return $image;
}

function filesize_formatted($file)
{
    $bytes = filesize($file);

    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return '1 byte';
    } else {
        return '0 bytes';
    }
}

// Delete Item Process Check 
function CheckRecordExist($column_name,$id,$table_name){

    $table_list = array();
    $tables = DB::select('SHOW TABLES');
    $DBtable_key="Tables_in_".env('DB_DATABASE');

    // Search Field
    $search_keyword = $column_name;

    // find the table of this keyword
    foreach($tables as $table)
    {
        if(in_array($search_keyword,\Schema::getColumnListing($table->$DBtable_key))){
            $table_list[] = $table->$DBtable_key;
        }
    }

    // if($column_name == "order_id")
    // {
    //     if(($key = array_search('order_items', $table_list)) !== false){
    //         unset($table_list[$key]);
    //     }
    // }
        
    if(count($table_list) != 0){
        foreach($table_list as $table){
            if($table != $table_name){
                $check_data = \DB::table($table)->where($search_keyword,$id)->get();
                if(count($check_data) != 0){
                    return false;
                }
            }
        }
    }
    return true;
}


function sendNotification($data) {
    $device_id='';
    
    // $data['title'] = "New Video";
    // $data['message'] = "Check the New Video";
    // dd($data);
    $device_ids = DB::table('notification_register')->get()->pluck('register_id')->toArray();
    sendOneSignalMessage($device_ids, $data);
}

/**
     * Send Notification Message
     * 
     * @param  array $device_ids  ['2588b22d-36fa-4116-82ab-3f106468cedb']
     * @param  array $device_data array(
	 *							     "type" => 11,
	 *							     "appointment_id"=>  250,
	 *								 "user_id"=> 34, 
	 *								 "id"=> 12,
	 *								 "doctor_id"=> 37,
	 *								 "question_id"=>  136,
	 *								 "bookmark"=> 0, 
     *								 "title"=> "Title",
     *                               "message" => "Message"
	 *								)
     * @return json              [description]
     */
    function sendOneSignalMessage($device_ids, $device_data) {
        $content = array(
        	"en" => isset($device_data['title']) ? $device_data['title'] : 'Video Title'
        );
        $device_contents = array(
				"type"           => isset($device_data['type']) ? $device_data['type'] : 'Videos',
                "v_id"           => isset($device_data['v_id']) ? $device_data['v_id'] : 0,
				"v_title"        => isset($device_data['v_title']) ? $device_data['v_title'] : "Video Name",                
				"v_view"         => isset($device_data['v_view']) ? $device_data['v_view'] : 0, 
				"v_size"         => isset($device_data['v_size']) ? $device_data['v_size'] : "0 MB", 
				"v_thumbnail"    => isset($device_data['v_thumbnail']) ? $device_data['v_thumbnail'] : 0,
				"v_path"         => isset($device_data['v_path']) ? $device_data['v_path'] : 0,
				"v_category"     => isset($device_data['v_category']) ? $device_data['v_category'] : 0,
				"image"          => isset($device_data['image']) ? $device_data['image'] : "", 
				"title"          => isset($device_data['title']) ? $device_data['title'] : 'Video Title',
				"message"        => isset($device_data['message']) ? $device_data['message'] : 'Video Message',
				"v_icon"         => isset($device_data['v_icon']) ? $device_data['v_icon'] : "",
				"v_image"        => isset($device_data['v_image']) ? $device_data['v_image'] : "",
				"url"            => isset($device_data['url']) ? $device_data['url'] : ""
            );
        // dd($device_contents);
        $fields = array(
            'app_id' => env('ONESIGNAL_API_KEY'),
            'include_player_ids' => $device_ids,
            'data' => $device_contents,
            'contents' => $content
        );

        $sendContent = json_encode($fields);
        // dd($sendContent);
        oneSignalAPI($sendContent);
    }

    function oneSignalAPI($sendContent) 
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                    'Authorization: Basic '.env('ONESIGNAL_REST_API_KEY')));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $sendContent);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);
        // dd($response);
        return $response;
    }



?>
