<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\IdsData;

class IdsDataController extends Controller
{
    public function index(Request $request)
    {
        $routes = \Route::current();
        $url = $routes->uri;
        $route = substr($url, 0, 3) == 'api'  ? true : false;
        if($route == true){
            $ids_data = IdsData::all();            
            return \Response::json([
                'status'  => true,
                'data' => $ids_data,
                'message' => "Ids List"
            ]);
        }else{
            $title = "Id Data List";
            $ids_data = IdsData::all();
            return view('idsData.index',compact('ids_data','title'));
        }
    }

    public function create($id = -1)
    {
        if($id == -1)
        {
            $title = "Add New Ids";
            $ids_data = new IdsData;
        }else
        {
            $title = "Edit Ids Data";
            $ids_data = IdsData::where('id',$id)->first();
        }        
        return view('idsData.create',compact('ids_data','title'));
    }

    public function store(Request $request)
    {   
        if($request->id == null){
            $idsDataInfo = array(
                "id_name"   => $request->id_name,
            );
            $validator = \Validator::make($idsDataInfo,
            [ 
                'id_name'    => 'required|unique:ids_datas'
            ]);                
            if($validator->fails()) 
            { 
                foreach($validator->getMessageBag()->toArray() as $error_data){
                    foreach($error_data as $error){
                        $errors[] = ucwords(" ".$error);
                    }
                }
                return redirect()->back()->withErrors($errors);
            }
        }
        $save_data = array(
            'id_name' => $request->id_name,
            'value' => $request->value,
        );
        if($request->id == null){
            IdsData::create($save_data);
            return redirect()->route('ids-data.index')->withSuccess("Ids data has been added successfully.");
        }else{
            IdsData::where('id',$request->id)->update(array('value' => $request->value));
            return redirect()->route('ids-data.index')->withSuccess("Ids data has been updated successfully.");
        }
    }  
    
    public function destroy($id)
    {
        IdsData::where('id',$id)->delete();
        return redirect()->route('ids-data.index')->withSuccess("Ids data has been deleted successfully.");
    }
}
