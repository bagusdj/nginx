<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Language;
use App\Category;
use DB;

class StaticController extends Controller
{
    public function CategoryLanguage(Request $request)
    {
        $language = Language::all();
        $category = Category::all();
        $category_data = array();
        if(count($category) != 0){
            foreach($category as $c){
                $c->logo = '/category/'.$c->logo;
                $category_data[] = $c;
            }
        }
        
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            "language"    => $language,
            'category'    => $category_data,
        ]);
    }

    public function reportindex(Request $request)
    {
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Reports List";
        $report_data = \App\Report::orderBy('id','desc')->paginate(10);
        $report_count = \App\Report::count();
        return view('reports.index',compact('report_data','report_count','page','title'));
    }

    public function changePWD()
    {
        $title = "Change Password";
        return view('auth.passwords.changePWD',compact('title'));
    }

    public function changePWDStore(Request $request)
    {
        if($request->password == $request->confirm_pwd)
        {
            $user = \Auth::user();
            $pwd = bcrypt($request->password);
            \App\User::where('id',$user->id)->update(array('password' => $pwd));
            return redirect()->route('change_pwd')->withSuccess("Password Change successfully.");
        }else{
            return redirect()->route('change_pwd')->withErrors("Your password and confirm password done not match. Try Agin.");
        }
    }

    public function PhoneNo(Request $request){
        $user = \Auth::user();
        $uid = $request->user_id;
        $phone = $request->phone;
        $phone_data = \App\User::where('id',$uid)->update(array('phone' => $phone));
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            //'data'    => $phone_data,
        ]);
    }


    public function Redeem(Request $request){
        //$user = \Auth::user();
        $uid = $request->user_id;
        $phone = $request->phone;
        $point = $request->point;
        $val = 0.1;
        $balance = $point * $val;
        
        $user = DB::table('users')->where('id', $request->user_id)->first();

        $data = array(
            'user_id' => $uid,
            'email' => $user->email,
            'phone' => $phone,
            'complete_flag' => 0,
            'balance' => $balance,
        );
        $redeem_save_data = \App\Redeem::create($data);

        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $redeem_save_data,
        ]);
    }

    public function redeemindex(Request $request)
    {
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Redeem Request List";
       
        $redeem_data = DB::table('redeem_management')->select('redeem_management.*','users.*')
                    ->Join('users','redeem_management.user_id', '=', 'users.id')
                    ->where('redeem_management.complete_flag', '=', 0)
                    ->orderBy('redeem_management.redeem_id','DESC')
                    ->paginate(10);
        //dd($redeem_data);
        $redeem_count = \App\Redeem::count();
        return view('redeem.index',compact('redeem_data','redeem_count','page','title'));
    }

    public function redeemcomplete(Request $request)
    {
		$page = isset($request->page) ? $request->page : 0;
    	//dd($request->redeem_id);
        \App\Redeem::where('redeem_id',$request->redeem_id)->delete();
        if($page == 0){
            return redirect()->route('redeem.index')->withSuccess("Redeem data has been deleted successfully.");
        }else{
            return redirect()->route('redeem.index',['page'=>$page])->withSuccess("Redeem data has been deleted successfully.");
        }
        
    }


}
