<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Video;
use App\Language;
use App\Category;
use App\Report;
use App\NotificatonRegister;
use Config;
use \App\Video_points;
use DB;


if (version_compare(PHP_VERSION, '7.2.0', '>=')) {
// Ignores notices and reports all other kinds... and warnings
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
// error_reporting(E_ALL ^ E_WARNING); // Maybe this is enough
}

class VideoController extends Controller
{
    public function VideoList(Request $request)
    {
        // dd($request->all());
        $video_data = array();
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $language_id = $request->l_id;
        $category_id = $request->c_id;
        $sort = $request->sort;
        $order_by = $request->order_by;

        $query = '';

        if($language_id != "-1"){
            $query = ' AND v.language_id='.$language_id.'';
        }

        if($category_id != "-1"){
            $query = ' AND v.category_id='.$category_id.'';
        }

        if($sort == "1" OR $order_by == "1")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.id DESC";
        }
        else if($sort == "2" OR $order_by == "0")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.id ASC";
        }
        else if($sort == "3")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.View DESC";
        }
        else if($sort == "4")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.View ASC";
        }
        else if($order_by == "2")
        {
            $query .= " ORDER BY v.video_of_day DESC, RAND()";
        }
        
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 '.$query.' LIMIT '.$start.','.$end);
                            // WHERE v.status = 1 '.$query);

        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                // $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                // $video->view = count($view_count);
                // $video->thumbnail = '/videos/image/'.$video->thumbnail;
                // $video->path = '/videos/'.$video->path;
                // $video_data[] = $video;


                $view_count = \App\ViewLike::where('video_id',$video->id)->where('type','view')->get();
                $favourite_count = \App\ViewLike::where('video_id',$video->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLike::where('video_id',$video->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $video->view = count($view_count);
                $video->favourite_count = count($favourite_count);
                $video->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video->liveurl = $video->liveurl;
                $video_data[] = $video;
            }
        }
        
        $video_data_total = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 '.$query.'');

        return \Response::json([
            'status'  => true,
            'message' => "Video List",
            "count"    => count($video_data_total),
            'data'    => $video_data,
        ]);
    }

    public function SearchList(Request $request)
    {
        $video_data = array();
        $keyword = $request->keyword;
        $videos = DB::select('SELECT id,title FROM `videos` WHERE status = 1');
        if(count($videos) != 0){
            $video_data = $videos;
        }
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function SearchVideoList(Request $request)
    {
        $video_data = array();
        $keyword = $request->keyword;
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v
                                LEFT JOIN categorys c ON c.id = v.category_id
                                LEFT JOIN languages l ON l.id = v.language_id
                                WHERE LOWER(v.title) LIKE LOWER(\'%'.$keyword.'%\') AND v.status = 1');
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                // $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                // $video->view = count($view_count);
                // $video->thumbnail = '/videos/image/'.$video->thumbnail;
                // $video->path = '/videos/'.$video->path;
                // $video_data[] = $video;

                $view_count = \App\ViewLike::where('video_id',$video->id)->where('type','view')->get();
                $video->view = count($view_count);
                $favourite_count = \App\ViewLike::where('video_id',$video->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLike::where('video_id',$video->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $video->favourite_count = count($favourite_count);
                $video->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video->liveurl = $video->liveurl;
                $video_data[] = $video;
            }
        }
        
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function TrendingVideo(Request $request)
    {
        $video_data = array();
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v
                        LEFT JOIN categorys c ON c.id = v.category_id
                        LEFT JOIN languages l ON l.id = v.language_id
                        WHERE v.trending=1 AND v.status = 1');
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                // $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                // $video->view = count($view_count);
                // $video->thumbnail = '/videos/image/'.$video->thumbnail;
                // $video->path = '/videos/'.$video->path;
                // $video_data[] = $video;

                $view_count = \App\ViewLike::where('video_id',$video->id)->where('type','view')->get();
                $video->view = count($view_count);
                $favourite_count = \App\ViewLike::where('video_id',$video->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLike::where('video_id',$video->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $video->favourite_count = count($favourite_count);
                $video->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video->liveurl = $video->liveurl;
                $video_data[] = $video;
            }
        }             
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function VideoUpload(Request $request)
    {
        $video_details = json_decode($request->upload_data);
        //dd($video_details->u_video_liveurl);
        $video_file = "";
        $img_file = "";
        $msg = '';
        $video_data = array(
            "title" => $video_details->u_video_title,
        );
        // "video" => $request->video_file,
        $validator = \Validator::make($video_data,
        [ 
            'title' => 'required|max:255|unique:videos',
        ]); 
        // 'title' => 'required|regex:/^[a-zA-Z0-9\s]+$/u|max:255|unique:videos',
        // 'video' => 'required|mimes:mp4,x-flv,x-mpegURL,MP2T,3gpp,quicktime,x-msvideo,x-ms-wmv',
            
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $msg[] = ucwords(" ".$error);
                }
            }
            return \Response::json([
                'status'  => false,
                'message' => ucwords(implode(',',$msg))
            ]);
        }

        if(isset($request->video_file)){
            $path = public_path().'/videos/';
            //$filename = str_replace('.', str_random(6).'.', $request->video_file->getClientOriginalName());
            $extension = $request->video_file->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;
            $request->video_file->move($path, $filename);
            $video_file = $filename;
        }

        if(isset($request->img_file)){
            $path = public_path().'/videos/image';
            //$filename = str_replace('.', str_random(6).'.', $request->img_file->getClientOriginalName());
            $extension = $request->img_file->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;
            $request->img_file->move($path, $filename);
            $img_file = $filename;
        }
        
        $language = Language::where('value',$video_details->u_video_language)->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $data = array(
            'thumbnail' => $img_file,
            'liveurl'=> isset($video_details->u_video_liveurl)?$video_details->u_video_liveurl:'',
            'path' => $video_file,
            'size' => $video_details->u_video_size,
            'title' => $video_details->u_video_title,
            'category_id' => $video_details->u_video_category,
            'language' => $video_details->u_video_language,
            'language_id' => $language_id,
            'user_id' => isset($video_details->u_video_id) ? $video_details->u_video_id : '',
            'username' => isset($video_details->u_video_username) ? $video_details->u_video_username : '',
            'email' => isset($video_details->u_video_email) ? $video_details->u_video_email : '',
        );
        //dd($data);
        $video_save_data = \App\Video::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Video upload successfully",
        ]);
    }
    

    public function PopularVideoList(Request $request)
    {
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $video_data = array();

        $video_data_total = DB::select('SELECT v.*,c.name as category_name, l.value as language_name, (SELECT COUNT(*) FROM viewlike WHERE `video_id`= v.id) AS view
                            FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 ORDER BY view DESC');
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name, (SELECT COUNT(*) FROM viewlike WHERE `video_id`= v.id) AS view
                            FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 ORDER BY v.view DESC LIMIT '.$start.','.$end);
                            // WHERE v.status = 1 ORDER BY view DESC');
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                // $video->thumbnail = '/videos/image/'.$video->thumbnail;
                // $video->path = '/videos/'.$video->path;
                // $video_data[] = $video;

                $favourite_count = \App\ViewLike::where('video_id',$video->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLike::where('video_id',$video->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $video->favourite_count = count($favourite_count);
                $video->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video->liveurl = $video->liveurl;
                $video_data[] = $video;
            }
        }

        return \Response::json([
            'status'  => true,
            'message' => "Video List",
            "count"    => count($video_data_total),
            'data'    => $video_data,
        ]);
    }

    public function RelatedVideoList(Request $request)
    {
        $video_data = array();
        $rlistcount = Config::get('constants.related_video_count');               // constant record
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.id != '.$request->v_id.' AND v.status = 1
                            ORDER BY RAND() LIMIT '.$rlistcount);
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                // $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                // $video->view = count($view_count);
                // $video->thumbnail = '/videos/image/'.$video->thumbnail;
                // $video->path = '/videos/'.$video->path;
                // $video_data[] = $video;

                $view_count = \App\ViewLike::where('video_id',$video->id)->where('type','view')->get();
                $favourite_count = \App\ViewLike::where('video_id',$video->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLike::where('video_id',$video->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $video->view = count($view_count);
                $video->favourite_count = count($favourite_count);
                $video->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video->liveurl = $video->liveurl;
                $video_data[] = $video;
            }
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function Reports(Request $request)
    {
        $data = array(
            'report_v_id' => $request->report_v_id,
            'report_v_content' => $request->report_v_content,
            'report_description' => $request->report_description,
        );
        $v_id = \App\Report::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }
     
    public function ViewLikeSave(Request $request)
    {
        $view_data = \App\ViewLike::where('video_id',$request->video_id)->where('user_id',$request->user_id)->where('type',$request->type)->first();
        if($request->type == "view")
        {
            if(count($view_data) == 0)
            {
                $flag = true;
            }else{
                $flag = false;
            }
        }else{
            if($request->value == 0){
                $view_data = \App\ViewLike::where('video_id',$request->video_id)->where('user_id',$request->user_id)->where('type',$request->type)->delete();
                $flag = false;
            }else{
                \App\ViewLike::where('video_id',$request->video_id)->where('user_id',$request->user_id)->where('type',$request->type)->delete();
                $flag = true;
                // if(count($view_data) == 0)
                // {
                //     $flag = true;
                // }else{
                //     $flag = false;
                // }
            }
        }

        if($flag == true)
        {
            $save_data = array(
                'video_id' => $request->video_id,
                'user_id' => $request->user_id,
                'type' => $request->type,
            );
         //dd($save_data);
            \App\ViewLike::create($save_data);
            if($request->type == "view")
            {
                $video_data = \App\Video::where('id',$request->video_id)->first();
                $total_view = $video_data->view + 1;
                \App\Video::where('id',$request->video_id)->update(array('view'=>$total_view));
            }
            return \Response::json([
                'status' => true,
                'message' => "Success",
            ]);
        }else{
            return \Response::json([
                'status' => false,
                'message' => "Success",
            ]);
        }
    }

    public function DownloadCount(Request $request)
    {
        $view_data = \App\DownloadCount::where('video_id',$request->video_id)->where('uid',$request->user_id)->first();
        //dd(count($view_data));

        if(count($view_data) == 0)
        {
            $flag = true;
        }else{
            $flag = false;
        }
        
        if($flag == true)
        {
        
            $save_data = array(
                'video_id' => $request->video_id,
                'uid' => $request->user_id,
                //'type' => $request->type,
            ); 
            //dd($save_data);
            \App\DownloadCount::create($save_data);

            //if(){
                $video_data = \App\Video::where('id',$request->video_id)->first();
                $total_down = $video_data->view + 1;
                \App\Video::where('id',$request->video_id)->update(array('download'=>$total_down));
            //}
            return \Response::json([
                'status' => true,
                'message' => "Success",
            ]);
        }
    }

    public function RegisterNotificaton(Request $request)
    {
        $check_data = NotificatonRegister::where('register_id', $request->register_id)->where('device_id', $request->device_id)->get();
        if(count($check_data) == 0)
        {
            $save = array(
                'register_id' => $request->register_id,
                'device_id' => $request->device_id,
            );
            \App\NotificatonRegister::create($save);
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }


    public function AppVideoPoint(Request $request)
    {
        $routes = \Route::current();
        $url = $routes->uri;
        $route = substr($url, 0, 3) == 'api'  ? true : false;
        if($route == true){
            $save_array = array(
                'video_id' => $request->video_id,
                'user_id'  => $request->user_id,
                'point'    => '10',
                'add_date' => date('Y-m-d')
            );
            
            // $checkVideo = \App\Video_points::where('add_date',date('Y-m-d'))->where('user_id',$request->user_id)->where('video_id',$request->video_id)->first();

            // if(count($checkVideo) == 0){            
                $totalPT = \App\Video_points::where('add_date',date('Y-m-d'))->where('user_id',$request->user_id)->sum('point');
                if($totalPT < 150){
                    \App\Video_points::create($save_array);
                    \App\User::where('id',$request->user_id)->increment('balance', "0.33");
                    $msg = "10 points added successfully";
                }else{
                    $msg = "Your Today earning exceed";
                }
    
                $info = \App\Video_points::where('add_date',date('Y-m-d'))->where('user_id',$request->user_id)->sum('point');
                return \Response::json([
                    'status'  => true,
                    'total_point' => $info,
                    'message' => $msg
                ]);
         // }else{
            // return \Response::json([
                     // 'status'  => true,
                     // 'message' => ''
                // ]);
        //}
        }
    }
}
