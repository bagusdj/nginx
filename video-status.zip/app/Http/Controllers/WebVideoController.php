<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Video;
use App\Language;
use App\Category;
use App\Report;
use Config;
use DB;
use Session;
use Yajra\Datatables\Datatables;

class WebVideoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Videoindex(Request $request)
    {
        //dd($request->page);
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Videos List";
        $video_data = Video::orderBy('id','desc')->paginate(10);
        $video_count = Video::count();
        return view('video.index',compact('video_data','title','video_count','page'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Videocreate(Request $request)
    {
        $page = isset($request->page) ? $request->page : 0;
        $relation = [
            'category'   => \App\Category::get()->pluck('name', 'id')->prepend('Please select', ''),
            'language'  => \App\Language::get()->pluck('value', 'value')->prepend('Please select', ''),
        ];
        if(isset($request->id)){
            $title = "Edit Videos";
            $video_data = Video::where('id',$request->id)->first();
        }else{
            $title = "Add New Video";
            $video_data = new Video;
        }
        return view('video.create',compact('video_data','title','page')+$relation);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Videostore(Request $request)
    {
        $session_id = auth()->user()->id;
        $user = DB::table('users')->where('id', $session_id)->first();
        //dd($user->name);
        //dd($request->all());
        $video_details = $request->all();
        $video_file = "";
        $img_file = "";
        $size = 0;
        $page = isset($request->page) ? $request->page : 0;
        if($request->id == null){
        
            $video_data = array(
                "title" => $video_details['title'],
                //"video" => $request->video_file,
                "img"   => $request->video_img,
            );
            // 'title' => 'required|regex:/^[a-zA-Z0-9\s]+$/u|max:255|unique:videos',
            $validator = \Validator::make($video_data,
            [ 
                'title' => 'required|max:255|unique:videos',
                //'video' => 'required|mimes:mp4,x-flv,x-mpegURL,MP2T,3gpp,quicktime,x-msvideo,x-ms-wmv',
                'img'    => 'required|mimes:jpeg,jpg,png,gif|max:10000'                                     // max 10000kb
            ]); 
                
        }else{
            $video_save_data = Video::where('id',$request->id)->first();
            $video_data = array(
                "title" => $video_details['title'],
            );
            if($video_details['title'] != $video_save_data->title){
                $validator = \Validator::make($video_data,
                [ 
                    'title' => 'required|max:255|unique:videos',
                ]);            
            }else{
                $validator = \Validator::make($video_data,
                [ 
                    'title' => 'required|max:255',
                ]);
            }
        }
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $errors[] = ucwords(" ".$error);
                }
            }
            // dd($msg);
            return redirect()->back()->withErrors($errors);
        }
        
            
        if(isset($request->video_file)){
            $video_size = $request->video_file->getClientSize();
            $size = $this->filesize_formatted($video_size);
            $extension = $request->video_file->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;            
            $path = public_path().'/videos/';
            //$filename = str_replace('.', str_random(6).'.', $request->video_file->getClientOriginalName());
            $request->video_file->move($path, $filename);
            $video_file = $filename;
        }else{
            $v_data = \App\Video::where('id',$request->id)->first();
            if($v_data !=''){
            $video_file = $v_data->path;
            $size = $v_data->size;
             }
            else{
            $video_file = '';
            $size = '';
            }
        }

        if(isset($request->video_img)){
            $path = public_path().'/videos/image';
            $extension = $request->video_img->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;
            //$filename = str_replace('.', str_random(6).'.', $request->video_img->getClientOriginalName());
            $request->video_img->move($path, $filename);
            $video_img = $filename;
        }else{
            $v_data = \App\Video::where('id',$request->id)->first();
            $video_img = $v_data->thumbnail;            
        }
        
        $language = Language::where('value',$video_details['language'])->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $savedata = array(
            'thumbnail' => $video_img,
            'liveurl' => $request->upload_url,
            'path' => $video_file,
            'size' => $size,
            'title' => $video_details['title'],
            'category_id' => $video_details['category_id'],
            'language' => $video_details['language'],
            'language_id' => $language_id,
            'username' => isset($user->name) ? $user->name : '',
            'email' => isset($user->email) ? $user->email : '',
        );
        //dd($savedata);
        if($page == 0){
            if($request->id == null){
                $video_save_data = \App\Video::create($savedata);
                return redirect()->route('video_list')->withSuccess("Video Successfully Saved.");
            }else{
                \App\Video::where('id',$request->id)->update($savedata);
                return redirect()->route('video_list')->withSuccess("Video Data Update Successfully.");
            }
        }else{
            if($request->id == null){
                $video_save_data = \App\Video::create($savedata);
                return redirect()->route('video_list',['page'=>$page])->withSuccess("Video Successfully Saved.");
            }else{
                \App\Video::where('id',$request->id)->update($savedata);
                return redirect()->route('video_list',['page'=>$page])->withSuccess("Video Data Update Successfully.");
            }
        }
        
    }

    public function VideoDelete(Request $request)
    {
        $page = isset($request->page) ? $request->page : 0;
        Video::where('id',$request->id)->delete();
        if($page == 0){
            return redirect()->route('video_list')->withSuccess("Video Delete Successfully.");
        }else{
            return redirect()->route('video_list',['page'=>$page])->withSuccess("Video Delete Successfully.");
        }
    }

    public function Videoapprove(Request $request)
    {
        $data = Video::where('id',$request->id)->first();
        if($request->name == "status"){
            if($data->status == 0){
                Video::where('id',$request->id)->update(array("status" => 1));
            }else{
                Video::where('id',$request->id)->update(array("status" => 0));
            }
        }else if($request->name == "trending"){
            if($data->trending == 0){
                Video::where('id',$request->id)->update(array("trending" => 1));
            }else{
                Video::where('id',$request->id)->update(array("trending" => 0));
            }
        }else{
            DB::table('videos')->update(array('video_of_day' => 0));
            Video::where('id',$request->id)->update(array("video_of_day" => 1));
        }
        
        if($request->name == "status"){
            if($data->notification == 0){
                $Ndata = array(
                    "type" => 1,
                    "v_id" => $data->id,
                    "v_title" => $data->title,
                    "v_view" => $data->view,
                    "v_thumbnail" => '/videos/image/'.$data->thumbnail,
                    "v_path" => '/videos/'.$data->path,
                    "v_category" => $data->category->name,
                    "image" => '/videos/image/'.$data->thumbnail,
                    'title' => "New Video",
                    'message' => "Check the New Video",
                );
                // $check = sendNotification($Ndata);
                Video::where('id',$request->id)->update(array("notification" => 1));
            }
        }
        
        return response()->json(['status'=>TRUE, 'message'=> ' Successfully.']);
    }

    public function filesize_formatted($bytes)
    {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } elseif ($bytes > 1) {
            return $bytes . ' bytes';
        } elseif ($bytes == 1) {
            return '1 byte';
        } else {
            return '0 bytes';
        }
    }

}
