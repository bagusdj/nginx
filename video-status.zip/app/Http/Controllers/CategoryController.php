<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Category List";
        $category_data = Category::orderBy('id','desc')->paginate(10);
        $category_count = Category::count();
        return view('category.index',compact('category_data','category_count','page','title'));
    }

    public function create(Request $request,$id = -1)
    {
        $page = isset($request->page) ? $request->page : 0;
        if($id == -1)
        {
            $title = "Add New Category";
            $category_data = new Category;
        }else
        {
            $title = "Edit Category Data";
            $category_data = Category::where('id',$id)->first();
        }        
        return view('category.create',compact('category_data','title','page'));
    }

    public function store(Request $request)
    {   
        // dd($request->all());
        $page = isset($request->page) ? $request->page : 0;
        if($request->id == null){        
            $category_data = array(
                "logo"   => $request->logo,
            );
            $validator = \Validator::make($category_data,
            [ 
                'logo'    => 'required|mimes:jpeg,jpg,png,gif|max:10000'                                     // max 10000kb
            ]); 
                
            if($validator->fails()) 
            { 
                foreach($validator->getMessageBag()->toArray() as $error_data){
                    foreach($error_data as $error){
                        $errors[] = ucwords(" ".$error);
                    }
                }
                return redirect()->back()->withErrors($errors);
            }
            $path = public_path().'/category/';
            $filename = str_replace(' ', '', $request->logo->getClientOriginalName());
            $request->logo->move($path, $filename);
            $logo_file = $filename;
        }else{
            if(isset($request->logo)){
                $path = public_path().'/category/';
                $filename = str_replace(' ', '', $request->logo->getClientOriginalName());
                $request->logo->move($path, $filename);
                $logo_file = $filename;
            }else{
                $category_data = Category::where('id',$request->id)->first();
                $logo_file = $category_data->logo;
            }
        }
        $logo_name = '';
        $save_data = array(
            'name' => $request->name,
            'logo' => $logo_file 
        );
        // dd($save_data);
        if($page == 0){
            if($request->id == null){
                Category::create($save_data);
                return redirect()->route('category.index')->withSuccess("Category data has been added successfully.");
            }else{
                Category::where('id',$request->id)->update($save_data);
                return redirect()->route('category.index')->withSuccess("Category data has been updated successfully.");
            }
        }else{
            if($request->id == null){
                Category::create($save_data);
                return redirect()->route('category.index',['page'=>$page])->withSuccess("Category data has been added successfully.");
            }else{
                Category::where('id',$request->id)->update($save_data);
                return redirect()->route('category.index',['page'=>$page])->withSuccess("Category data has been updated successfully.");
            }
        }

    }

    public function destroy(Request $request,$id)
    {
        $page = isset($request->page) ? $request->page : 0;
        $column_name = "category_id";
        $table_name = "categorys";
        $del_status = CheckRecordExist($column_name,$id,$table_name);
        if($del_status == false){
            return redirect()->back()->withErrors("Sorry, You Can't Delete Because It Is Already Used Somewhere");
        }
        Category::where('id',$id)->delete();
        if($page == 0){
            return redirect()->route('category.index')->withSuccess("Category data has been deleted successfully.");
        }else{
            return redirect()->route('category.index',['page'=>$page])->withSuccess("Category data has been deleted successfully.");
        }
    }
}
