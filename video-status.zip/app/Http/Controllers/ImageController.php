<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Image;
use App\Language;
use App\Category;
use App\Report;
use App\NotificatonRegister;
use Config;
use \App\Image_points;
use DB;

if (version_compare(PHP_VERSION, '7.2.0', '>=')) {
// Ignores notices and reports all other kinds... and warnings
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
// error_reporting(E_ALL ^ E_WARNING); // Maybe this is enough
}

class ImageController extends Controller
{
    public function ImageList(Request $request)
    {
        // dd($request->all());
        $image_data = array();
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $language_id = $request->l_id;
        $category_id = $request->c_id;
        $sort = $request->sort;
        $order_by = $request->order_by;

        $query = '';

        if($language_id != "-1"){
            $query = ' AND i.language_id='.$language_id.'';
        }

        if($category_id != "-1"){
            $query = ' AND i.category_id='.$category_id.'';
        }

        if($sort == "1" OR $order_by == "1")
        {
            $query .= " ORDER BY i.image_of_day DESC, i.id DESC";
        }
        else if($sort == "2" OR $order_by == "0")
        {
            $query .= " ORDER BY i.image_of_day DESC, i.id ASC";
        }
        else if($sort == "3")
        {
            $query .= " ORDER BY i.image_of_day DESC, i.View DESC";
        }
        else if($sort == "4")
        {
            $query .= " ORDER BY i.image_of_day DESC, i.View ASC";
        }
        else if($order_by == "2")
        {
            $query .= " ORDER BY i.image_of_day DESC, RAND()";
        }
        
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $image_all_data = DB::select('SELECT i.*,c.name as category_name, l.value as language_name FROM `images` i 
                            LEFT JOIN categorys c ON c.id = i.category_id
                            LEFT JOIN languages l ON l.id = i.language_id
                            WHERE i.status = 1 '.$query.' LIMIT '.$start.','.$end);
                            // WHERE v.status = 1 '.$query);

        if(count($image_all_data) != 0)
        {
            foreach($image_all_data as $image)
            {
                // $view_count = \App\ViewLikeImage::where('image_id',$image->id)->get();
                // $image->view = count($view_count);
                // $image->image = '/image/'.$image->image;
                // $image_data[] = $image;


                $view_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','view')->get();
                $favourite_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLikeImage::where('image_id',$image->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $image->view = count($view_count);
                $image->favourite_count = count($favourite_count);
                $image->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $image->image = '/image/'.$image->image;
                $image_data[] = $image;
            }
        }
        
        $image_data_total = DB::select('SELECT i.*,c.name as category_name, l.value as language_name FROM `images` i 
                            LEFT JOIN categorys c ON c.id = i.category_id
                            LEFT JOIN languages l ON l.id = i.language_id
                            WHERE i.status = 1 '.$query.'');

        return \Response::json([
            'status'  => true,
            'message' => "Image List",
            "count"    => count($image_data_total),
            'data'    => $image_data,
        ]);
    }

    public function SearchList(Request $request)
    {
        $image_data = array();
        $keyword = $request->keyword;
        $images = DB::select('SELECT id,title FROM `images` WHERE status = 1');
        if(count($images) != 0){
            $image_data = $images;
        }
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $image_data,
        ]);
    }

    public function SearchImageList(Request $request)
    {
        $image_data = array();
        $keyword = $request->keyword;
        $image_all_data = DB::select('SELECT i.*,c.name as category_name, l.value as language_name FROM `images` i
                                LEFT JOIN categorys c ON c.id = i.category_id
                                LEFT JOIN languages l ON l.id = i.language_id
                                WHERE LOWER(i.title) LIKE LOWER(\'%'.$keyword.'%\') AND i.status = 1');
        if(count($image_all_data) != 0)
        {
            foreach($image_all_data as $images)
            {
                // $view_count = \App\ViewLike::where('image_id',$image->id)->get();
                // $image->view = count($view_count);
                // $image->image = '/image/'.$image->image;
                // $image_data[] = $image;

                $view_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','view')->get();
                $favourite_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLikeImage::where('image_id',$image->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $image->view = count($view_count);
                $image->favourite_count = count($favourite_count);
                $image->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $image->image = '/image/'.$image->image;
                $image_data[] = $image;
            }
        }
        
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $image_data,
        ]);
    }

    public function TrendingImage(Request $request)
    {
        $image_data = array();
        $image_all_data = DB::select('SELECT i.*,c.name as category_name, l.value as language_name FROM `images` i
                        LEFT JOIN categorys c ON c.id = v.category_id
                        LEFT JOIN languages l ON l.id = v.language_id
                        WHERE i.trending=1 AND i.status = 1');
        if(count($image_all_data) != 0)
        {
            foreach($image_all_data as $image)
            {
                // $view_count = \App\ViewLike::where('image_id',$image->id)->get();
                // $image->view = count($view_count);
                // $image->image = '/image/'.$image->image;
                // $image_data[] = $image;

                $view_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','view')->get();
                $favourite_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLikeImage::where('image_id',$image->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $image->view = count($view_count);
                $image->favourite_count = count($favourite_count);
                $image->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $image->image = '/image/'.$image->image;
                $image_data[] = $image;
            }
        }             
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $image_data,
        ]);
    }

    public function ImageUpload(Request $request)
    {
        $image_details = json_decode($request->upload_data);
        
        $image_file = "";
        $msg = '';
        $image_data = array(
            "title" => $image_details->u_image_title,
        );
        
        $validator = \Validator::make($image_data,
        [ 
            'title' => 'required|max:255|unique:images',
        ]); 
        
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $msg[] = ucwords(" ".$error);
                }
            }
            return \Response::json([
                'status'  => false,
                'message' => ucwords(implode(',',$msg))
            ]);
        }
    
        if(isset($request->img_file)){
            $path = public_path().'/image';
            //$filename = str_replace('.', str_random(6).'.', $request->img_file->getClientOriginalName());
            $extension = $request->img_file->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;
            $request->img_file->move($path, $filename);
            $image_file = $filename;
        }
        //dd($request->img_file);
        $language = Language::where('value',$image_details->u_image_language)->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $data = array(
            'image' => $image_file,
            'size' => $image_details->u_image_size,
            'title' => $image_details->u_image_title,
            'category_id' => $image_details->u_image_category,
            'language' => $image_details->u_image_language,
            'language_id' => $language_id,
            'user_id' => isset($image_details->u_image_id) ? $image_details->u_image_id : '' ,
            'username' => isset($image_details->u_image_username) ? $image_details->u_image_username : '',
            'email' => isset($image_details->u_image_email) ? $image_details->u_image_email : '',
        );
        //dd($data);
        $image_save_data = \App\Image::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Image upload successfully",
        ]);
    }
    

    public function PopularImageList(Request $request)
    {
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $image_data = array();

        $image_data_total = DB::select('SELECT i.*,c.name as category_name, l.value as language_name, (SELECT COUNT(*) FROM viewlike_image WHERE `image_id`= i.id) AS view
                            FROM `images` i 
                            LEFT JOIN categorys c ON c.id = i.category_id
                            LEFT JOIN languages l ON l.id = i.language_id
                            WHERE i.status = 1 ORDER BY view DESC');
        $image_all_data = DB::select('SELECT i.*,c.name as category_name, l.value as language_name, (SELECT COUNT(*) FROM viewlike_image WHERE `image_id`= i.id) AS view
                            FROM `images` i 
                            LEFT JOIN categorys c ON c.id = i.category_id
                            LEFT JOIN languages l ON l.id = i.language_id
                            WHERE i.status = 1 ORDER BY i.view DESC LIMIT '.$start.','.$end);
                            // WHERE v.status = 1 ORDER BY view DESC');
        if(count($image_all_data) != 0)
        {
            foreach($image_all_data as $image)
            {
                $image->image = 'image/'.$image->image;
               
                $favourite_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLikeImage::where('image_id',$image->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $image->favourite_count = count($favourite_count);
                $image->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $image->image = '/'.$image->image;
                $image_data[] = $image;
            }
        }

        return \Response::json([
            'status'  => true,
            'message' => "Image List",
            "count"    => count($image_data_total),
            'data'    => $image_data,
        ]);
    }

    public function RelatedImageList(Request $request)
    {
        $image_data = array();
        $rlistcount = Config::get('constants.related_image_count');               // constant record
        $image_all_data = DB::select('SELECT i.*,c.name as category_name, l.value as language_name FROM `images` i 
                            LEFT JOIN categorys c ON c.id = i.category_id
                            LEFT JOIN languages l ON l.id = i.language_id
                            WHERE i.id != '.$request->v_id.' AND i.status = 1
                            ORDER BY RAND() LIMIT '.$rlistcount);
        if(count($image_all_data) != 0)
        {
            foreach($image_all_data as $image)
            {
                // $view_count = \App\ViewLike::where('image_id',$image->id)->get();
                // $image->view = count($view_count);
                // $image->image = '/image/'.$image->image;
                // $image_data[] = $image;

                $view_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','view')->get();
                $favourite_count = \App\ViewLikeImage::where('image_id',$image->id)->where('type','favourite')->get();
                $favourite_type = \App\ViewLikeImage::where('image_id',$image->id)->where('user_id',$request->user_id)->where('type','favourite')->get();
                $image->view = count($view_count);
                $image->favourite_count = count($favourite_count);
                $image->favourite_type = (count($favourite_type) == 0) ? 0 : 1;
                $image->image = '/image/'.$image->image;
                $image_data[] = $image;
            }
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
            'data'    => $image_data,
        ]);
    }

    public function imageReports(Request $request)
    {
        $data = array(
            'report_i_id' => $request->report_i_id,
            'report_i_content' => $request->report_i_content,
            'report_description' => $request->report_description,
        );
        $v_id = \App\Report::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }
     
    public function ImageViewLikeSave(Request $request)
    {

        $view_data = \App\ViewLikeImage::where('image_id',$request->image_id)->where('user_id',$request->user_id)->where('type',$request->type)->first();
        //dd(count(array_filter($view_data)));
        if($request->type == "view")
        {
            if(count($view_data) == 0)
            {
                $flag = true;
            }else{
                $flag = false;
            }
        }else{
            if($request->value == 0){
                $view_data = \App\ViewLikeImage::where('image_id',$request->image_id)->where('user_id',$request->user_id)->where('type',$request->type)->delete();
                $flag = false;
            }else{
                if(count($view_data) == 0)
                {
                    $flag = true;
                }else{
                    $flag = false;
                }
            }
        }

        if($flag == true)
        {
            $save_data = array(
                'image_id' => $request->image_id,
                'user_id' => $request->user_id,
                'type' => $request->type,
            );
            // dd($save_data);
            \App\ViewLikeImage::create($save_data);
            if($request->type == "view")
            {
                $image_data = \App\Image::where('id',$request->image_id)->first();
                $total_view = $image_data->view + 1;
                \App\Image::where('id',$request->image_id)->update(array('view'=>$total_view));
            }
            return \Response::json([
                'status' => true,
                'message' => "Success",
            ]);
        }else{
            return \Response::json([
                'status' => false,
                'message' => "Success",
            ]);
        }
    }
    public function DownloadCountImage(Request $request)
    {
        $view_data = \App\DownloadCountImage::where('image_id',$request->image_id)->where('uid',$request->user_id)->first();
        //dd(count($view_data));

        if(count($view_data) == 0)
        {
            $flag = true;
        }else{
            $flag = false;
        }
        
        if($flag == true)
        {
        
            $save_data = array(
                'image_id' => $request->image_id,
                'uid' => $request->user_id,
                //'type' => $request->type,
            ); 
            //dd($save_data);
            \App\DownloadCountImage::create($save_data);

            //if(){
                $image_data = \App\Image::where('id',$request->image_id)->first();
                $total_down = $image_data->view + 1;
                \App\Image::where('id',$request->image_id)->update(array('download'=>$total_down));
            //}
            return \Response::json([
                'status' => true,
                'message' => "Success",
            ]);
        }
    }


    public function RegisterImageNotificaton(Request $request)
    {
        $check_data = NotificatonRegister::where('register_id', $request->register_id)->where('device_id', $request->device_id)->get();
        if(count($check_data) == 0)
        {
            $save = array(
                'register_id' => $request->register_id,
                'device_id' => $request->device_id,
            );
            \App\NotificatonRegister::create($save);
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }


    public function AppImagePoint(Request $request)
    {
        $routes = \Route::current();
        $url = $routes->uri;
        $route = substr($url, 0, 3) == 'api'  ? true : false;
        if($route == true){
            $save_array = array(
                'image_id' => $request->image_id,
                'user_id'  => $request->user_id,
                'point'    => '10',
                'add_date' => date('Y-m-d')
            );
            
              
                $totalPT = \App\Image_points::where('add_date',date('Y-m-d'))->where('user_id',$request->user_id)->sum('point');
                if($totalPT < 150){
                    \App\Image_points::create($save_array);
                    \App\User::where('id',$request->user_id)->increment('balance', "0.33");
                    $msg = "10 points added successfully";
                }else{
                    $msg = "Your Today earning exceed";
                }
    
                $info = \App\Image_points::where('add_date',date('Y-m-d'))->where('user_id',$request->user_id)->sum('point');
                return \Response::json([
                    'status'  => true,
                    'total_point' => $info,
                    'message' => $msg
                ]);
         // }else{
            // return \Response::json([
                     // 'status'  => true,
                     // 'message' => ''
                // ]);
        //}
        }
    }
}
