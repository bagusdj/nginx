<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function VideoNotification(Request $request)
    {
        $title = "Video Notification";
        if(isset($request->id)){
            $video_info = \App\Video::where('id',$request->id)->first();
        }else{
            $video_info = new \App\Video;
        }
        $video_data = \App\Video::get();
        return view('home.videonotification',compact('title','video_data','video_info'));
    }

    public function ImageNotification(Request $request)
    {
        $title = "Image Notification";
        if(isset($request->id)){
            $image_info = \App\Image::where('id',$request->id)->first();
        }else{
            $image_info = new \App\Image;
        }
        $image_data = \App\Image::get();
        return view('home.imagenotification',compact('title','image_data','image_info'));
    }

    public function VideoNotificationSave(Request $request)
    {
        $data = \App\Video::where('id',$request->video_id)->first();
        $Ndata = array(
            "type"        => 2,
            "v_id"        => $data->id,
            "v_title"     => $data->title,
            "v_view"      => $data->view,
            "v_size"      => $data->size, 
            "v_thumbnail" => '/videos/image/'.$data->thumbnail,
            "v_path"      => '/videos/'.$data->path,
            "v_liveurl"  =>  $data->liveurl,
            "v_category"  => $data->category->name,
            "image"       => '/videos/image/'.$data->thumbnail,
            "title"       => $request->title,
            "message"     => $request->msg,
            "v_icon"      => $request->icon,
            "v_image"     => $request->video_img,
        );
        $check = sendNotification($Ndata);
        return redirect()->route('video_notification')->withSuccess("Video Notification Message Send Successfully.");
    }

    public function ImageNotificationSave(Request $request)
    {
        $data = \App\Image::where('id',$request->image_id)->first();
        $Ndata = array(
            "type"        => 2,
            "v_id"        => $data->id,
            "v_title"     => $data->title,
            "v_view"      => $data->view,
            "v_size"      => $data->size, 
            "v_image" => '/img/'.$data->image,
            "v_category"  => $data->category->name,
            "image"       => '/videos/image/'.$data->thumbnail,
            "title"       => $request->title,
            "message"     => $request->msg,
            "v_icon"      => $request->icon,
            "v_image"     => $request->video_img,
        );
        $check = sendNotification($Ndata);
        return redirect()->route('image_notification')->withSuccess("Image Notification Message Send Successfully.");
    }


    public function URLNotification(Request $request)
    { 
        $title = "URL Notification";
        return view('home.URLnotification',compact('title'));
    }

    public function URLNotificationSave(Request $request)
    {
        $Ndata = array(
            "type"    => 3,
            "title"   => $request->title,
            "message" => $request->msg,
            "v_icon"  => $request->icon,
            "v_image" => $request->video_img,
            "url"     => $request->video_url,
        );
        $check = sendNotification($Ndata);
        return redirect()->route('url_notification')->withSuccess("URL Notification Message Send Successfully.");
    }

    public function Notification(Request $request)
    {
        $title = "Simple Notification";
        return view('home.notification',compact('title'));
    }

    public function NotificationSave(Request $request)
    {
        $Ndata = array(
            "type"    => 0,
            "title"   => $request->title,
            "message" => $request->msg,
        );
        $check = sendNotification($Ndata);
        return redirect()->route('home')->withSuccess("Notification Message Send Successfully.");
    }
}
