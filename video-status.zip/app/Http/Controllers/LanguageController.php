<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Language;

class LanguageController extends Controller
{
    public function index(Request $request)
    {
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Language List";
        $language_data = Language::orderBy('id','desc')->paginate(10);
        $language_count = Language::count();
        return view('language.index',compact('language_data','language_count','page','title'));
    }

    public function create(Request $request,$id = -1)
    {
        $page = isset($request->page) ? $request->page : 0;
        if($id == -1)
        {
            $title = "Add New Language";
            $language_data = new Language;
        }else
        {
            $title = "Edit Language Data";
            $language_data = Language::where('id',$id)->first();
        }        
        return view('language.create',compact('language_data','title','page'));
    }

    public function store(Request $request)
    {   
        $page = isset($request->page) ? $request->page : 0;
        $save_data = array(
            'value' => $request->value,
        );

        if($page == 0){
            if($request->id == null){
                Language::create($save_data);
                return redirect()->route('language.index')->withSuccess("Language data has been added successfully.");
            }else{
                Language::where('id',$request->id)->update($save_data);
                return redirect()->route('language.index')->withSuccess("Language data has been updated successfully.");
            }
        }else{
            if($request->id == null){
                Language::create($save_data);
                return redirect()->route('language.index',['page'=>$page])->withSuccess("Language data has been added successfully.");
            }else{
                Language::where('id',$request->id)->update($save_data);
                return redirect()->route('language.index',['page'=>$page])->withSuccess("Language data has been updated successfully.");
            }
        }

    }

    public function destroy(Request $request,$id)
    {
        $page = isset($request->page) ? $request->page : 0;
        $column_name = "language_id";
        $table_name = "languages";
        $del_status = CheckRecordExist($column_name,$id,$table_name);
        if($del_status == false){
            return redirect()->back()->withErrors("Sorry, You Can't Delete Because It Is Already Used Somewhere");
        }
        Language::where('id',$id)->delete();
        if($page == 0){
            return redirect()->route('language.index')->withSuccess("Language data has been deleted successfully.");
        }else{
            return redirect()->route('language.index',['page'=>$page])->withSuccess("Language data has been deleted successfully.");
        }
    }
}
