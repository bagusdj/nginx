<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Image;
use App\Language;
use App\Category;
use App\Report;
use Config;
use DB;
use Session;
use Yajra\Datatables\Datatables;

class WebImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Imageindex(Request $request)
    {
        if(isset($request->page)){
            $page = $request->page;
        }else{
            $page = '';
        }
        $title = "Images List";
        $image_data = Image::orderBy('id','desc')->paginate(10);
        $image_count = Image::count();
        return view('image.index',compact('image_data','title','image_count','page'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Imagecreate(Request $request)
    {
        $page = isset($request->page) ? $request->page : 0;
        $relation = [
            'category'   => \App\Category::get()->pluck('name', 'id')->prepend('Please select', ''),
            'language'  => \App\Language::get()->pluck('value', 'value')->prepend('Please select', ''),
        ];
        if(isset($request->id)){
            $title = "Edit Images";
            $image_data = Image::where('id',$request->id)->first();
        }else{
            $title = "Add New Image";
            $image_data = new Image;
        }
        return view('image.create',compact('image_data','title','page')+$relation);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Imagestore(Request $request)
    {
        $session_id = auth()->user()->id;
        $user = DB::table('users')->where('id', $session_id)->first();
         //dd($request->all());
        $image_details = $request->all();
        $image_file = "";
        $size = 0;
        $page = isset($request->page) ? $request->page : 0;
        if($request->id == null){
        
            $image_data = array(
                "title" => $image_details['title'],
                "image" => $request->image_file,
               
            );
            
            $validator = \Validator::make($image_data,
            [ 
                'title' => 'required|max:255|unique:images',
                'image'    => 'required|mimes:jpeg,jpg,png,gif|max:10000'   
                                              // max 10000kb
            ]); 
                
        }else{
            $image_save_data = Image::where('id',$request->id)->first();
            $image_data = array(
                "title" => $image_details['title'],
            );
            if($image_details['title'] != $image_save_data->title){
                $validator = \Validator::make($image_data,
                [ 
                    'title' => 'required|max:255|unique:images',
                ]);            
            }else{
                $validator = \Validator::make($image_data,
                [ 
                    'title' => 'required|max:255',
                ]);
            }
        }
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $errors[] = ucwords(" ".$error);
                }
            }
            // dd($msg);
            return redirect()->back()->withErrors($errors);
        }
        
   
       if(isset($request->image_file)){
            $image_size = $request->image_file->getClientSize();
            $size = $this->filesize_formatted($image_size);
            $path = public_path().'/image/';
            $extension = $request->image_file->getClientOriginalExtension();
            $timestamp = str_random(10).'.'.$extension;
            $filename = $timestamp;
            $request->image_file->move($path, $filename);
            $image_file = $filename;
        }else{
            $i_data = \App\Image::where('id',$request->id)->first();
            $image_file = $i_data->image;  
            $size = $i_data->size;          
        }
        
        $language = Language::where('value',$image_details['language'])->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $savedata = array(
            'image' => $image_file,
            'size' => $size,
            'title' => $image_details['title'],
            'category_id' => $image_details['category_id'],
            'language' => $image_details['language'],
            'language_id' => $language_id,
            'username' => isset($user->name) ? $user->name : '',
            'email' => isset($user->email) ? $user->email : '',
        );
       // dd($savedata);
        //die;
        if($page == 0){
            if($request->id == null){
                $image_save_data = \App\Image::create($savedata);
                return redirect()->route('image_list')->withSuccess("Image Successfully Saved.");
            }else{
                \App\Image::where('id',$request->id)->update($savedata);
                return redirect()->route('image_list')->withSuccess("Image Data Update Successfully.");
            }
        }else{
            if($request->id == null){
                $image_save_data = \App\Image::create($savedata);
                return redirect()->route('image_list',['page'=>$page])->withSuccess("Image Successfully Saved.");
            }else{
                \App\Image::where('id',$request->id)->update($savedata);
                return redirect()->route('image_list',['page'=>$page])->withSuccess("Image Data Update Successfully.");
            }
        }
        
    }

    public function ImageDelete(Request $request)
    {
        $page = isset($request->page) ? $request->page : 0;
        Image::where('id',$request->id)->delete();
        if($page == 0){
            return redirect()->route('image_list')->withSuccess("Image Delete Successfully.");
        }else{
            return redirect()->route('image_list',['page'=>$page])->withSuccess("Image Delete Successfully.");
        }
    }

    public function Imageapprove(Request $request)
    {
        $data = Image::where('id',$request->id)->first();
        if($request->name == "status"){
            if($data->status == 0){
                Image::where('id',$request->id)->update(array("status" => 1));
            }else{
                Image::where('id',$request->id)->update(array("status" => 0));
            }
        }else if($request->name == "trending"){
            if($data->trending == 0){
                Image::where('id',$request->id)->update(array("trending" => 1));
            }else{
                Image::where('id',$request->id)->update(array("trending" => 0));
            }
        }else{
            DB::table('images')->update(array('image_of_day' => 0));
            Image::where('id',$request->id)->update(array("image_of_day" => 1));
        }
        
        if($request->name == "status"){
            if($data->notification == 0){
                $Ndata = array(
                    "type" => 1,
                    "v_id" => $data->id,
                    "v_title" => $data->title,
                    "v_view" => $data->view,
                    "v_image" => '/image/'.$data->image,
                    "v_category" => $data->category->name,
                    "image" => '/image/'.$data->image,
                    'title' => "New Image",
                    'message' => "Check the New Image",
                );
                // $check = sendNotification($Ndata);
                Image::where('id',$request->id)->update(array("notification" => 1));
            }
        }
        
        return response()->json(['status'=>TRUE, 'message'=> ' Successfully.']);
    }

    public function filesize_formatted($bytes)
    {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } elseif ($bytes > 1) {
            return $bytes . ' bytes';
        } elseif ($bytes == 1) {
            return '1 byte';
        } else {
            return '0 bytes';
        }
    }

}
