<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewLike extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'viewlike';
    protected $fillable = ['video_id','user_id','phone_id','type'];
}
