<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image_points extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'image_points';
    protected $fillable = ['image_id','user_id','point','add_date'];

}
