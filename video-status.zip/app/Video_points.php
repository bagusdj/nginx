<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Video_points extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'video_points';
    protected $fillable = ['video_id','user_id','point','add_date'];

}
