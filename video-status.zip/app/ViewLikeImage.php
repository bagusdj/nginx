<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewLikeImage extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'viewlike_image';
    protected $fillable = ['image_id','user_id','phone_id','type'];
}
