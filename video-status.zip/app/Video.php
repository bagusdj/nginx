<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'videos';
    protected $fillable = ['thumbnail','liveurl','path','size','view','category_id','title','language_id','language','video_of_day','user_id','username','email'];

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}
