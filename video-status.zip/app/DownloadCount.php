<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DownloadCount extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'downloadcount';
    protected $fillable = ['video_id','uid'];
}
