<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdsData extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'ids_datas';
    protected $fillable = ['id_name','value'];
}
