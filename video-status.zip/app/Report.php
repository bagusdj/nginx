<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'reports';
    protected $fillable = ['report_v_id','report_v_content','report_description'];
}
