-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2019 at 07:50 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `image_module`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorys`
--

CREATE TABLE `categorys` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categorys`
--

INSERT INTO `categorys` (`id`, `name`, `logo`, `created_at`, `updated_at`) VALUES
(1, 'Festival', 'piano6.jpg', '2019-04-06 11:03:29', '2019-04-06 11:03:29');

-- --------------------------------------------------------

--
-- Table structure for table `downloadcount`
--

CREATE TABLE `downloadcount` (
  `id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloadcount`
--

INSERT INTO `downloadcount` (`id`, `video_id`, `uid`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2019-04-17 19:56:37', '2019-04-17 19:56:37'),
(2, 2, 1, '2019-04-17 19:57:34', '2019-04-17 19:57:34');

-- --------------------------------------------------------

--
-- Table structure for table `downloadcount_image`
--

CREATE TABLE `downloadcount_image` (
  `id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloadcount_image`
--

INSERT INTO `downloadcount_image` (`id`, `image_id`, `uid`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2019-04-17 20:03:24', '2019-04-17 20:03:24'),
(2, 3, 1, '2019-04-17 20:04:05', '2019-04-17 20:04:05'),
(3, 1, 1, '2019-04-17 20:22:50', '2019-04-17 20:22:50');

-- --------------------------------------------------------

--
-- Table structure for table `ids_datas`
--

CREATE TABLE `ids_datas` (
  `id` int(11) NOT NULL,
  `id_name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` varchar(225) DEFAULT NULL,
  `size` varchar(225) DEFAULT NULL,
  `view` int(11) DEFAULT '0',
  `download` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(225) DEFAULT NULL,
  `language` varchar(225) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `image_of_day` int(11) DEFAULT '0',
  `username` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `trending` tinyint(2) DEFAULT '0',
  `status` int(2) DEFAULT '0',
  `notification` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image`, `size`, `view`, `download`, `category_id`, `title`, `language`, `language_id`, `image_of_day`, `username`, `email`, `trending`, `status`, `notification`, `created_at`, `updated_at`) VALUES
(3, 'YoIzGO0oyc.jpg', '0', 0, 1, 1, 'Demo', 'English', 1, 0, '', '', 0, 0, 0, '2019-04-18 01:34:05', '2019-04-17 20:04:05'),
(4, 'OHkiRqSIuc.jpg', '0', 0, 0, 1, 'First', 'English', 1, 0, '', '', 0, 0, 0, '2019-04-08 20:22:26', '2019-04-08 20:22:26');

-- --------------------------------------------------------

--
-- Table structure for table `image_points`
--

CREATE TABLE `image_points` (
  `id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `point` text,
  `add_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `value`, `created_at`, `updated_at`) VALUES
(1, 'English', '2019-04-06 11:03:36', '2019-04-06 11:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `lucky_user`
--

CREATE TABLE `lucky_user` (
  `id` int(11) NOT NULL,
  `phone` varchar(75) NOT NULL,
  `price` varchar(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_register`
--

CREATE TABLE `notification_register` (
  `id` int(11) NOT NULL,
  `register_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `redeem_management`
--

CREATE TABLE `redeem_management` (
  `redeem_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(225) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `complete_flag` int(1) NOT NULL,
  `balance` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `redeem_management`
--

INSERT INTO `redeem_management` (`redeem_id`, `user_id`, `email`, `phone`, `complete_flag`, `balance`, `created_at`, `updated_at`) VALUES
(3, 1, 'Nirali.kanani@bhavitechnologies.com', '8989898989', 0, 200, '2019-04-25 17:11:16', '2019-04-25 17:11:16');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `report_v_id` int(11) NOT NULL,
  `report_v_content` varchar(255) DEFAULT NULL,
  `report_description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lucky_user` int(2) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `lucky_user`, `password`, `remember_token`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Nirali kanani', 'Nirali.kanani@bhavitechnologies.com', '8989898989', 0, '$2y$10$07clfRuxy0o8Qz3meo4e9eWes9I2grocY5.Sj0YzoOjJATMdzhV5G', 'KzhDWEP6X9EfkBwLtYoxERhD9T7FzFKVa4kyq4Hu3bphE7rGoRGzsDO24eOD', 'admin', '2019-04-04 10:35:41', '2019-04-17 20:31:53'),
(2, 'demo', 'kishan@gmail.com', '8989898989', 0, '$2y$10$v1oJ7jkwdklEAyoajK7t8OJdzH9145eFZsU1LQ93TfPDKy6rz0Rgy', NULL, 'user', '2019-04-09 11:18:29', '2019-04-17 20:32:17');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `view` int(11) DEFAULT '0',
  `download` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `video_of_day` tinyint(1) DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `trending` tinyint(2) DEFAULT '0',
  `status` int(2) DEFAULT '0',
  `notification` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `thumbnail`, `path`, `size`, `view`, `download`, `category_id`, `title`, `language`, `language_id`, `video_of_day`, `username`, `email`, `trending`, `status`, `notification`, `created_at`, `updated_at`) VALUES
(1, '7uiVEAMyyl.png', 'drnF2Zok60.mp4', '1.01 MB', 2, 3, 1, 'test', 'English', 1, 0, '', '', 0, 0, 0, '2019-04-06 11:18:02', '2019-04-17 19:56:37'),
(2, 'ugJq5eriy8.png', 'Px3yL814Hb.mp4', '1.01 MB', 0, 1, 1, 'test33', 'English', 1, 0, '', '', 0, 0, 0, '2019-04-06 11:40:08', '2019-04-17 19:57:34'),
(3, 'yKrzowX3Bh.png', 'GljVpMnbEs.mp4', '1.01 MB', 0, 0, 1, 'dfdgf', 'English', 1, 0, 'Nirali kanani', 'Nirali.kanani@bhavitechnologies.com', 0, 0, 0, '2019-04-11 11:58:48', '2019-04-11 11:58:48');

-- --------------------------------------------------------

--
-- Table structure for table `video_points`
--

CREATE TABLE `video_points` (
  `id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `point` text,
  `add_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video_points`
--

INSERT INTO `video_points` (`id`, `video_id`, `user_id`, `point`, `add_date`, `created_at`, `updated_at`) VALUES
(3, 5, 4, '10', '2018-12-15', '2018-12-15 19:51:47', '2018-12-15 19:51:47'),
(4, 5, 4, '10', '2018-12-15', '2018-12-15 19:51:55', '2018-12-15 19:51:55'),
(7, 59, 2, '10', '2018-12-16', '2018-12-17 01:36:44', '2018-12-17 01:36:44');

-- --------------------------------------------------------

--
-- Table structure for table `viewlike`
--

CREATE TABLE `viewlike` (
  `id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `phone_id` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `viewlike`
--

INSERT INTO `viewlike` (`id`, `video_id`, `phone_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 1, 'abcd1234', 'view', '2019-04-09 12:18:42', '2019-04-09 12:18:42');

-- --------------------------------------------------------

--
-- Table structure for table `viewlike_image`
--

CREATE TABLE `viewlike_image` (
  `id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `phone_id` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `viewlike_image`
--

INSERT INTO `viewlike_image` (`id`, `image_id`, `phone_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 1, 'abcd1234', 'view', '2019-04-09 12:18:05', '2019-04-09 12:18:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorys`
--
ALTER TABLE `categorys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloadcount`
--
ALTER TABLE `downloadcount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloadcount_image`
--
ALTER TABLE `downloadcount_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ids_datas`
--
ALTER TABLE `ids_datas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image_points`
--
ALTER TABLE `image_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lucky_user`
--
ALTER TABLE `lucky_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_register`
--
ALTER TABLE `notification_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191)),
  ADD KEY `password_resets_token_index` (`token`(191));

--
-- Indexes for table `redeem_management`
--
ALTER TABLE `redeem_management`
  ADD PRIMARY KEY (`redeem_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_points`
--
ALTER TABLE `video_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewlike`
--
ALTER TABLE `viewlike`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewlike_image`
--
ALTER TABLE `viewlike_image`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorys`
--
ALTER TABLE `categorys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `downloadcount`
--
ALTER TABLE `downloadcount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `downloadcount_image`
--
ALTER TABLE `downloadcount_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ids_datas`
--
ALTER TABLE `ids_datas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `image_points`
--
ALTER TABLE `image_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lucky_user`
--
ALTER TABLE `lucky_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_register`
--
ALTER TABLE `notification_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `redeem_management`
--
ALTER TABLE `redeem_management`
  MODIFY `redeem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `video_points`
--
ALTER TABLE `video_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `viewlike`
--
ALTER TABLE `viewlike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `viewlike_image`
--
ALTER TABLE `viewlike_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
