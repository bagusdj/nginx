<?php

return [

	'USER' => [
			'DEFAULT_IMAGE'   => '/images/user-profile.png',
		],
];
